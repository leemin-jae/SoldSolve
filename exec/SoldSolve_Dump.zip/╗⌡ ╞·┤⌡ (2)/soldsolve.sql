-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: i7c110.p.ssafy.io    Database: soldsolve
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chat`
--

DROP TABLE IF EXISTS `chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat` (
  `chat_id` int NOT NULL AUTO_INCREMENT,
  `chat_content` varchar(200) DEFAULT NULL,
  `chat_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `room_id` int DEFAULT NULL,
  `user_pk` int DEFAULT NULL,
  PRIMARY KEY (`chat_id`),
  KEY `FKm38tfuuhbqvc3jrrat6q4k01j` (`room_id`),
  KEY `FKryext9b6lvvfnw1cnxjd8745j` (`user_pk`),
  CONSTRAINT `FKm38tfuuhbqvc3jrrat6q4k01j` FOREIGN KEY (`room_id`) REFERENCES `room` (`room_id`),
  CONSTRAINT `FKryext9b6lvvfnw1cnxjd8745j` FOREIGN KEY (`user_pk`) REFERENCES `user` (`user_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat`
--

LOCK TABLES `chat` WRITE;
/*!40000 ALTER TABLE `chat` DISABLE KEYS */;
INSERT INTO `chat` VALUES (3,'2000만 메소인가요?','2022-08-18 01:46:22',2,8),(13,'로션 가격 문의좀 하고 싶습니다~~','2022-08-18 02:39:02',7,17),(14,'저기요~~','2022-08-18 02:39:13',7,17),(15,'네고 없습니다','2022-08-18 02:39:23',7,6),(16,'안녕하세용','2022-08-18 03:09:32',8,3),(17,'만득님','2022-08-18 03:09:37',8,3),(18,'ㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎ','2022-08-18 03:09:46',8,3),(19,'!@##$$%^&&','2022-08-18 03:09:49',8,3),(20,'그건 쫌,,','2022-08-18 03:10:18',2,13),(21,'???','2022-08-18 03:10:30',8,17),(22,'/ㅠㅓ포ㅓ','2022-08-18 03:10:31',8,17),(23,'ㅗㅓㅗㅓㅓ','2022-08-18 03:10:32',8,17),(24,'네','2022-08-18 05:40:16',7,6),(25,'님님!','2022-08-18 06:00:08',9,3),(26,'님님님','2022-08-18 06:00:34',9,3),(27,'님님','2022-08-18 06:00:44',9,3),(28,'수료증 판매 신고요','2022-08-18 06:41:04',10,13),(30,'헉 ㅜㅜ','2022-08-18 07:42:15',10,7),(37,'라이브에서 글러브 5만원에 사기로 한 사람입니다!','2022-08-18 07:47:14',12,15),(38,'넵 더 궁금한점은 없으신가요?','2022-08-18 07:47:52',12,7),(39,'네 상품 자세히 볼 수 있어 좋았어요!','2022-08-18 07:48:26',12,15),(40,'내일 싸피광주캠퍼스 앞 오후 6시 괜찮으신가요??','2022-08-18 07:48:51',12,7),(41,'네 너무 좋아요! 그 때 뵐게요~~','2022-08-18 07:49:08',12,15),(42,'넵~ 내일 뵙겠습니다~','2022-08-18 07:49:36',12,7),(43,'와우 건후님껀가요?','2022-08-18 10:48:48',13,18),(44,'물품 말 안해주면 어떤 물품인지 몰라용 ㅎㅎ..','2022-08-18 11:35:50',13,8),(45,'구입하게해주세요','2022-08-18 13:23:14',14,1),(46,'알겠습니다','2022-08-18 13:23:34',14,5),(47,'이것좀 저한테 팔아주세요','2022-08-18 13:59:26',16,10),(48,'ㅋㅋㅋㅋㅋㅋㅋ','2022-08-18 13:59:43',16,10),(49,'갤럭시 플립 파시나요?','2022-08-18 14:34:37',17,10),(50,'안녕하세요! 플립3 상품 구매 원합니다!','2022-08-18 14:34:42',18,5),(51,'ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ','2022-08-18 14:49:01',13,18),(52,'그런 심각한 오류 말하지마세요 ㅜㅜㅜ','2022-08-18 14:49:05',13,18),(53,'사인 축구공이엇습니다 ㅜ','2022-08-18 14:49:13',13,18),(54,'라이브때 노래 불러주시나요','2022-08-18 14:52:32',19,18),(55,'현토에버 자소서도 팔아주세요 ㅜㅜ','2022-08-18 14:53:15',20,18),(56,'가격 제시 받아요','2022-08-18 14:56:56',20,19),(57,'무슨 말을 해도?','2022-08-18 14:58:04',20,19),(58,'이게 몰랐는데 어떤제품 보고 연락온건지 모르긴하네요 ㅋㅋ','2022-08-18 14:58:07',19,7),(59,'ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ','2022-08-18 14:59:20',20,18),(60,'아냐.. 아는걸로해...','2022-08-18 14:59:33',19,18),(61,'얼마인가요','2022-08-18 15:42:13',21,20),(62,'오..','2022-08-18 15:42:17',21,20),(63,'오 메시지 남아있네','2022-08-18 15:42:44',21,20),(64,'아아','2022-08-18 15:44:16',22,20),(65,'아아어','2022-08-18 15:44:19',22,20),(66,'아','2022-08-18 15:44:20',22,20),(67,'.','2022-08-18 15:44:21',22,20),(68,'11','2022-08-18 15:44:27',22,20),(69,'<h1>아아</h1>','2022-08-18 15:44:49',22,20),(70,'오','2022-08-18 15:44:52',22,20),(71,'테스트테스트','2022-08-18 15:44:59',22,20),(72,'테테스트','2022-08-18 15:45:01',22,20),(73,'ㅁ','2022-08-18 15:45:05',22,20),(74,'ㅁ','2022-08-18 15:45:05',22,20),(75,'ㅁㅁ','2022-08-18 15:45:06',22,20),(76,'ㅁ','2022-08-18 15:45:06',22,20),(77,'ㅁ','2022-08-18 15:45:06',22,20),(78,'ㅁ','2022-08-18 15:45:06',22,20),(79,'ㅁ','2022-08-18 15:45:07',22,20),(80,'ㅁ','2022-08-18 15:45:07',22,20),(81,'ㅁ','2022-08-18 15:45:07',22,20),(82,'ㅁ','2022-08-18 15:45:11',22,20),(83,'ㅁㅁ','2022-08-18 15:45:12',22,20),(84,'ㅁ','2022-08-18 15:45:13',22,20),(85,'아하','2022-08-18 15:45:24',22,20),(86,'계속 남아있나용','2022-08-18 15:46:09',22,20),(87,'계속 남아있나용','2022-08-18 15:46:16',22,20),(88,'아아','2022-08-18 15:46:18',22,20),(89,'아','2022-08-18 15:46:20',22,20),(90,'아아','2022-08-18 15:46:29',22,20),(91,'아','2022-08-18 15:46:31',22,20);
/*!40000 ALTER TABLE `chat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deal`
--

DROP TABLE IF EXISTS `deal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deal` (
  `deal_id` int NOT NULL AUTO_INCREMENT,
  `buyer_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  PRIMARY KEY (`deal_id`),
  KEY `FKescqrp6gh6m5y10682vk41q7w` (`buyer_id`),
  KEY `FKssa4j4c9uaou3wsbh9ktb343p` (`product_id`),
  CONSTRAINT `FKescqrp6gh6m5y10682vk41q7w` FOREIGN KEY (`buyer_id`) REFERENCES `user` (`user_pk`),
  CONSTRAINT `FKssa4j4c9uaou3wsbh9ktb343p` FOREIGN KEY (`product_id`) REFERENCES `product` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deal`
--

LOCK TABLES `deal` WRITE;
/*!40000 ALTER TABLE `deal` DISABLE KEYS */;
INSERT INTO `deal` VALUES (1,15,23),(2,8,62),(3,17,16),(4,1,56);
/*!40000 ALTER TABLE `deal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `live`
--

DROP TABLE IF EXISTS `live`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `live` (
  `live_id` int NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  PRIMARY KEY (`live_id`),
  UNIQUE KEY `UK_d254yu9lvlygnttb5dp6kq62e` (`session_id`),
  KEY `FK4btdqn37hgcjretuullv4dpjg` (`product_id`),
  CONSTRAINT `FK4btdqn37hgcjretuullv4dpjg` FOREIGN KEY (`product_id`) REFERENCES `product` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `live`
--

LOCK TABLES `live` WRITE;
/*!40000 ALTER TABLE `live` DISABLE KEYS */;
/*!40000 ALTER TABLE `live` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message` (
  `message_id` int NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `is_read` bit(1) DEFAULT NULL,
  `written_times` datetime(6) DEFAULT NULL,
  `user_pk` int DEFAULT NULL,
  PRIMARY KEY (`message_id`),
  KEY `FKvqijbcmtuc1j6b8cg53eg0yl` (`user_pk`),
  CONSTRAINT `FKvqijbcmtuc1j6b8cg53eg0yl` FOREIGN KEY (`user_pk`) REFERENCES `user` (`user_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
INSERT INTO `message` VALUES (1,'떵유(ehddb2252) 님이 미개봉 새제품 삼성 43인치 스마트 모니터 M7 S43BM700(28)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '','2022-08-18 01:30:54.476000',8),(2,'떵유(ehddb2252) 님이 미개봉 새제품 삼성 43인치 스마트 모니터 M7 S43BM700(28)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '','2022-08-18 01:30:59.076000',8),(3,'떵유(ehddb2252)이 채팅을 요청했습니다.',_binary '','2022-08-18 01:31:13.916000',8),(4,'yuzu(yuzu1) 님이 에어팟 프로 팔아요~(17)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '','2022-08-18 01:34:09.589000',7),(5,'yuzu(yuzu1) 님이 플스3  그란투스리모6  게임기 판매(11)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '\0','2022-08-18 01:34:15.619000',6),(6,'후건이(hoo)이 채팅을 요청했습니다.',_binary '','2022-08-18 01:46:13.775000',13),(7,'솔드솔브(soldsolve) 님이 귀여운 말랑이 무드등 팔아요 ~ 라이브 가능(23)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '','2022-08-18 02:07:22.946000',8),(8,'솔드솔브(soldsolve)이 채팅을 요청했습니다.',_binary '','2022-08-18 02:07:27.977000',8),(9,'솔드솔브(soldsolve) 님이 귀여운 말랑이 무드등 팔아요 ~ 라이브 가능(23)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '','2022-08-18 02:11:14.543000',8),(10,'솔드솔브(soldsolve)이 채팅을 요청했습니다.',_binary '','2022-08-18 02:11:17.681000',8),(11,'귀여운 말랑이 무드등 팔아요 ~ 라이브 가능(23) 의 거래가 완료되었습니다',_binary '','2022-08-18 02:13:13.056000',15),(12,'귀여운 말랑이 무드등 팔아요 ~ 라이브 가능(23) 의 거래가 완료되었습니다',_binary '','2022-08-18 02:13:13.070000',15),(13,'이건후(hoo)이 채팅을 요청했습니다.',_binary '','2022-08-18 02:34:22.517000',15),(14,'야구공 팔아요(62) 의 거래가 완료되었습니다',_binary '','2022-08-18 02:34:33.079000',8),(15,'야구공 팔아요(62) 의 거래가 완료되었습니다',_binary '','2022-08-18 02:34:33.099000',8),(16,'이건후(hoo)이 채팅을 요청했습니다.',_binary '','2022-08-18 02:36:03.312000',7),(17,'이만득(alswo96) 님이 더 심플 데일리 로션(16)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '\0','2022-08-18 02:38:24.381000',6),(18,'라이브 요청 상품 더 심플 데일리 로션의 라이브가 2022-08-18 04:43에 시작합니다.',_binary '\0','2022-08-18 02:38:42.990000',17),(19,'이만득(alswo96)이 채팅을 요청했습니다.',_binary '\0','2022-08-18 02:38:54.139000',6),(20,'찜한 상품 더 심플 데일리 로션의 라이브 방송이 시작했습니다.',_binary '','2022-08-18 02:40:30.617000',17),(21,'찜한 상품 더 심플 데일리 로션의 라이브 방송이 시작했습니다.',_binary '\0','2022-08-18 02:41:34.591000',17),(22,'찜한 상품 더 심플 데일리 로션의 라이브 방송이 시작했습니다.',_binary '\0','2022-08-18 02:45:00.127000',17),(23,'사용자닉네임(user) 님이 운동 기구(63)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '\0','2022-08-18 03:09:19.463000',17),(24,'사용자닉네임(user)이 채팅을 요청했습니다.',_binary '\0','2022-08-18 03:09:25.221000',17),(25,'찜한 상품 더 심플 데일리 로션의 라이브 방송이 시작했습니다.',_binary '\0','2022-08-18 03:13:42.644000',17),(26,'더 심플 데일리 로션(16) 의 거래가 완료되었습니다',_binary '\0','2022-08-18 03:17:55.760000',17),(27,'더 심플 데일리 로션(16) 의 거래가 완료되었습니다',_binary '\0','2022-08-18 03:17:55.768000',17),(28,'이만득(alswo96) 님이 탄산 음료(5)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '\0','2022-08-18 05:05:27.194000',6),(29,'라이브 요청 상품 탄산 음료의 라이브가 2022-08-18 17:08에 시작합니다.',_binary '\0','2022-08-18 05:05:49.891000',17),(30,'찜한 상품 탄산 음료의 라이브 방송이 시작했습니다.',_binary '\0','2022-08-18 05:06:12.011000',17),(31,'이만득(alswo96) 님이 헤어드라이기(66)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '\0','2022-08-18 05:37:47.837000',6),(32,'찜한 상품 헤어드라이기의 라이브 방송이 시작했습니다.',_binary '\0','2022-08-18 05:39:10.605000',17),(33,'사용자닉네임(user) 님이 떵유 캐릭터 팝니다(39)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '','2022-08-18 05:59:53.725000',13),(34,'사용자닉네임(user)이 채팅을 요청했습니다.',_binary '','2022-08-18 06:00:03.346000',13),(35,'찜한 상품 떵유 캐릭터 팝니다의 라이브 방송이 시작했습니다.',_binary '\0','2022-08-18 06:35:29.863000',3),(36,'찜한 상품 떵유 캐릭터 팝니다의 라이브 방송이 시작했습니다.',_binary '\0','2022-08-18 06:35:55.206000',3),(37,'찜한 상품 떵유 캐릭터 팝니다의 라이브 방송이 시작했습니다.',_binary '\0','2022-08-18 06:36:32.497000',3),(38,'찜한 상품 에어팟 프로 팔아요~의 라이브 방송이 시작했습니다.',_binary '','2022-08-18 06:37:23.059000',10),(39,'yuzu(yuzu1) 님이 싸피 수료증 팔아요(57)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '','2022-08-18 06:37:40.557000',7),(40,'떵유(ehddb2252)이 채팅을 요청했습니다.',_binary '','2022-08-18 06:40:58.120000',7),(41,'solsol(soldsolve) 님이 야구 글러브 팔아요(61)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '','2022-08-18 07:08:11.829000',7),(42,'solsol(soldsolve)이 채팅을 요청했습니다.',_binary '','2022-08-18 07:08:18.339000',7),(43,'solsol(soldsolve)이 채팅을 요청했습니다.',_binary '','2022-08-18 07:46:21.903000',7),(44,'찜한 상품 떵유 캐릭터 팝니다의 라이브 방송이 시작했습니다.',_binary '','2022-08-18 08:07:35.273000',3),(45,'찜한 상품 떵유 캐릭터 팝니다의 라이브 방송이 시작했습니다.',_binary '\0','2022-08-18 08:11:23.201000',3),(46,'찜한 상품 떵유 캐릭터 팝니다의 라이브 방송이 시작했습니다.',_binary '\0','2022-08-18 08:12:38.262000',3),(47,'찜한 상품 떵유 캐릭터 팝니다의 라이브 방송이 시작했습니다.',_binary '\0','2022-08-18 08:13:25.470000',3),(48,'yuzu2(yuzu2)이 채팅을 요청했습니다.',_binary '','2022-08-18 10:48:33.322000',8),(49,'슬슬이(dudgnscjstk)이 채팅을 요청했습니다.',_binary '','2022-08-18 13:23:09.411000',5),(50,'귀여운 강아지 보고가세요(56) 의 거래가 완료되었습니다',_binary '','2022-08-18 13:23:39.999000',1),(51,'귀여운 강아지 보고가세요(56) 의 거래가 완료되었습니다',_binary '\0','2022-08-18 13:23:40.008000',5),(52,'이건후(hoo)이 채팅을 요청했습니다.',_binary '\0','2022-08-18 13:33:30.939000',5),(53,'yuzu(yuzu1)이 채팅을 요청했습니다.',_binary '\0','2022-08-18 13:59:21.064000',6),(54,'yuzu(yuzu1) 님이 구찌 길티 남자 향수 팔아요(58)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '','2022-08-18 14:00:18.363000',7),(55,'yuzu(yuzu1) 님이 갤럭시플립 3 새상품 판매합니다(100)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '\0','2022-08-18 14:33:43.732000',1),(56,'김싸피(김싸피) 님이 갤럭시플립 3 새상품 판매합니다(100)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '\0','2022-08-18 14:33:58.802000',1),(57,'yuzu(yuzu1) 님이 갤럭시플립 3 새상품 판매합니다(101)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '\0','2022-08-18 14:34:02.659000',1),(58,'yuzu(yuzu1)이 채팅을 요청했습니다.',_binary '\0','2022-08-18 14:34:31.486000',1),(59,'김싸피(김싸피)이 채팅을 요청했습니다.',_binary '\0','2022-08-18 14:34:32.486000',1),(60,'햄솜(haengsong) 님이 갤럭시플립 3 새상품 판매합니다(100)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '\0','2022-08-18 14:38:02.672000',1),(61,'yuzu2(yuzu2) 님이 갤럭시플립 3 새상품 판매합니다(100)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '\0','2022-08-18 14:38:56.302000',1),(62,'yuzu2(yuzu2) 님이 갤럭시플립 3 새상품 판매합니다(100)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '\0','2022-08-18 14:45:39.760000',1),(63,'너납치된거야(너납치된거야) 님이 갤럭시플립 3 새상품 판매합니다(100)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 5명 ]',_binary '\0','2022-08-18 23:46:42.449000',1),(64,'yuzu2(yuzu2) 님이 블루투스 마이크 팔아요(46)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '','2022-08-18 14:52:05.659000',7),(65,'yuzu2(yuzu2)이 채팅을 요청했습니다.',_binary '','2022-08-18 14:52:10.096000',7),(66,'yuzu2(yuzu2)이 채팅을 요청했습니다.',_binary '','2022-08-18 14:53:03.116000',19),(67,'yuzu2(yuzu2) 님이 ★SSAFY 합격 자소서 / 자소서 첨삭 / 면접 꿀팁 / 싸피 꿀팁★(112)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '','2022-08-18 14:53:19.498000',19),(68,'햄솜(haengsong) 님이 ★SSAFY 합격 자소서 / 자소서 첨삭 / 면접 꿀팁 / 싸피 꿀팁★(112)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '','2022-08-18 15:23:52.285000',19),(69,'ssafy(ssafy)이 채팅을 요청했습니다.',_binary '\0','2022-08-18 15:42:05.491000',21),(70,'ssafy(ssafy) 님이 코로나 팔아요(113)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '\0','2022-08-18 15:42:54.648000',21),(71,'ssafy(ssafy) 님이 코로나 팔아요(113)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '\0','2022-08-18 15:42:59.454000',21),(72,'ssafy(ssafy) 님이 원숭이 인형 팜(105)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 1명 ]',_binary '\0','2022-08-18 15:44:11.131000',18),(73,'ssafy(ssafy)이 채팅을 요청했습니다.',_binary '\0','2022-08-18 15:44:13.883000',18),(74,'라이브 요청 상품 갤럭시플립 3 새상품 판매합니다의 라이브가 2022-08-19 01:53에 시작합니다.',_binary '\0','2022-08-18 16:53:24.864000',10),(75,'라이브 요청 상품 갤럭시플립 3 새상품 판매합니다의 라이브가 2022-08-19 01:53에 시작합니다.',_binary '\0','2022-08-18 16:53:24.871000',5),(76,'라이브 요청 상품 갤럭시플립 3 새상품 판매합니다의 라이브가 2022-08-19 01:53에 시작합니다.',_binary '\0','2022-08-18 16:53:24.879000',7),(77,'라이브 요청 상품 갤럭시플립 3 새상품 판매합니다의 라이브가 2022-08-19 01:53에 시작합니다.',_binary '','2022-08-18 16:53:24.886000',18),(78,'라이브 요청 상품 갤럭시플립 3 새상품 판매합니다의 라이브가 2022-08-19 01:53에 시작합니다.',_binary '\0','2022-08-18 16:53:24.894000',12),(79,'찜한 상품 갤럭시플립 3 새상품 판매합니다의 라이브 방송이 시작했습니다.',_binary '\0','2022-08-18 16:53:48.790000',10),(80,'찜한 상품 갤럭시플립 3 새상품 판매합니다의 라이브 방송이 시작했습니다.',_binary '\0','2022-08-18 16:53:48.796000',5),(81,'찜한 상품 갤럭시플립 3 새상품 판매합니다의 라이브 방송이 시작했습니다.',_binary '\0','2022-08-18 16:53:48.803000',7),(82,'찜한 상품 갤럭시플립 3 새상품 판매합니다의 라이브 방송이 시작했습니다.',_binary '\0','2022-08-18 16:53:48.810000',18),(83,'찜한 상품 갤럭시플립 3 새상품 판매합니다의 라이브 방송이 시작했습니다.',_binary '\0','2022-08-18 16:53:48.816000',12),(84,'모아이(dlalswo9801) 님이 갤럭시플립 3 새상품 판매합니다(101)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 2명 ]',_binary '\0','2022-08-19 09:08:03.999000',1),(85,'모아이(dlalswo9801) 님이 갤럭시플립 3 새상품 판매합니다(100)에 라이브를 요청했습니다. [현재 총 라이브 요청 인원 : 6명 ]',_binary '\0','2022-08-19 09:08:36.772000',1);
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice` (
  `notice_id` int NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `written_times` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`notice_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice`
--

LOCK TABLES `notice` WRITE;
/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
INSERT INTO `notice` VALUES (1,'안녕하세요.\nSold Solve 제작팀입니다.\n2022년 8월 18일자로 Sold Solve가 공식적으로 오픈하게 되었습니다. 많은 축하와 관심 부탁드립니다.\n부족한 점이 많을 수 있습니다. 불편한 점은 언제든지 건의해주시면 개선하도록 노력하겠습니다.\n\n감사합니다.\n다들 공통 프로젝트하느라 고생하셨습니다.','[공지] Sold Solve 공식 오픈','2022-08-18 02:45:26.237000'),(3,'안녕하세요 쏠쏠개발팀입니다.\n\n8월19일 자정에 발표준비를 위한 최종 빌드 작업이 있으므로\n10분간 서비스 사용이중단됩니다.\n\n발표 화이팅입니다.','[점검] 8월19일 00시00분 ~ 00시10분 웹페이지 점검','2022-08-18 14:11:20.044000'),(5,'안녕하세요.\n쏠드쏠브 개발팀 입니다.\n\n쏠쏠의 새로운 기능  \"실시간 인기검색어\" 가 추가되었습니다.\n모든 유저들은 메인화면에 다른 유저들이 어떤 것을 많이 찾는지 쉽게 확인 할 수 있도록 실시간 인기검색어 기능을 구현하게 되었습니다.\n\n많은 이용 바랍니다.','[업데이트]  인기검색어 업데이트','2022-08-18 14:14:23.345000');
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offer`
--

DROP TABLE IF EXISTS `offer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `offer` (
  `offer_id` int NOT NULL AUTO_INCREMENT,
  `price` int NOT NULL,
  `time` datetime(6) DEFAULT NULL,
  `no` int DEFAULT NULL,
  `user_pk` int DEFAULT NULL,
  PRIMARY KEY (`offer_id`),
  KEY `FKlhvsgre9k551m47pfgqtu5w12` (`no`),
  KEY `FK496npjgq3bw6lfrx28vq80gay` (`user_pk`),
  CONSTRAINT `FK496npjgq3bw6lfrx28vq80gay` FOREIGN KEY (`user_pk`) REFERENCES `user` (`user_pk`),
  CONSTRAINT `FKlhvsgre9k551m47pfgqtu5w12` FOREIGN KEY (`no`) REFERENCES `product` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offer`
--

LOCK TABLES `offer` WRITE;
/*!40000 ALTER TABLE `offer` DISABLE KEYS */;
INSERT INTO `offer` VALUES (1,100000,'2022-08-18 01:48:52.371000',34,8),(2,105000,'2022-08-18 01:49:09.554000',34,7),(4,110000,'2022-08-18 01:50:30.544000',34,8),(5,5,'2022-08-18 05:06:35.772000',5,17),(6,15000,'2022-08-18 05:40:00.018000',66,17),(7,11000,'2022-08-18 05:40:02.292000',66,8),(8,16000,'2022-08-18 05:40:15.464000',66,8),(9,100000,'2022-08-18 06:35:03.913000',38,6),(10,160000,'2022-08-18 06:35:41.618000',38,8),(11,170000,'2022-08-18 06:36:07.949000',38,17),(12,180000,'2022-08-18 06:36:13.950000',38,17),(13,210000,'2022-08-18 06:36:18.682000',38,15),(14,5000,'2022-08-18 06:36:24.135000',38,17),(15,123214,'2022-08-18 06:36:27.120000',38,17),(16,13535,'2022-08-18 06:36:28.759000',38,17),(17,0,'2022-08-18 06:36:29.369000',38,17),(18,13525,'2022-08-18 06:36:34.915000',38,17),(19,1234677,'2022-08-18 06:36:37.006000',38,17),(20,130000,'2022-08-18 06:37:38.231000',17,15),(21,140000,'2022-08-18 06:37:41.425000',17,17),(22,160000,'2022-08-18 06:38:07.235000',17,8),(23,170000,'2022-08-18 06:38:39.862000',17,6),(24,100000,'2022-08-18 06:38:46.144000',17,6),(25,10000,'2022-08-18 15:04:04.873000',108,18),(26,9000,'2022-08-18 15:09:33.552000',108,7),(27,100,'2022-08-18 15:15:27.686000',108,20),(28,99,'2022-08-18 15:17:07.540000',108,7),(29,98,'2022-08-18 15:23:26.551000',108,20),(30,97,'2022-08-18 15:30:39.789000',108,7),(31,86,'2022-08-18 15:32:07.329000',108,20);
/*!40000 ALTER TABLE `offer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pop_word`
--

DROP TABLE IF EXISTS `pop_word`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pop_word` (
  `pop_id` int NOT NULL AUTO_INCREMENT,
  `count` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pop_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pop_word`
--

LOCK TABLES `pop_word` WRITE;
/*!40000 ALTER TABLE `pop_word` DISABLE KEYS */;
INSERT INTO `pop_word` VALUES (1,20,'아이패드'),(2,6,'수정동'),(3,13,'피아노'),(4,1,'차에'),(5,7,'말랑이'),(6,2,'인형'),(7,3,'썬크림'),(8,1,'선크림'),(9,7,'로션'),(10,3,'갤럭시'),(11,2,'운동'),(12,1,'탄산'),(13,1,'메이플'),(14,5,'삼성'),(15,1,'갤럭시워치'),(16,1,'섬성'),(17,2,'안소니'),(18,1,'마이크'),(19,1,'책'),(20,2,'워치'),(21,5,'플립');
/*!40000 ALTER TABLE `pop_word` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `no` int NOT NULL AUTO_INCREMENT,
  `category` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `live_time` datetime(6) DEFAULT NULL,
  `price` int NOT NULL,
  `region` varchar(255) DEFAULT NULL,
  `state` int NOT NULL DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `view_count` int NOT NULL,
  `user_pk` int DEFAULT NULL,
  PRIMARY KEY (`no`),
  KEY `FK9i0haxfdt1layqid5u40wgyw0` (`user_pk`),
  CONSTRAINT `FK9i0haxfdt1layqid5u40wgyw0` FOREIGN KEY (`user_pk`) REFERENCES `user` (`user_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'digital','별로 안쓴 아이폰 팔아요. 네고 금지~',NULL,1000000,'광주',0,'아이폰',9,6),(2,'digital','바빠서 빨리 처분합니다. 채팅 주세요',NULL,500000,'부산',0,'아이폰 엄청 쌈',2,6),(3,'digital','2017년형 아이패드 9.7 5세대입니다\n오른쪽 상단이 사진과같이 파손되어있습니다.\n유튜브나 게임하는데 지장없어요',NULL,100000,'광주광역시 신가동',0,'모서리 깨진 아이패드 팔아요',14,7),(4,'appliances','구매후. 새상품입니다 텍도 뜯지않고 택배받은그대로 보관중입니다',NULL,60000,'광주',0,'디월트 공구함 새상품. 판매합니다',6,6),(5,'etc','필요하신 분 들고가세요','2022-08-18 08:08:00.000000',10000,'부산',0,'탄산 음료',8,6),(6,'digital','두달 전 구입해서 사용하다 다른 걸로 갈아타면서 내놓습니다 \n모니터암 전용 USB 케이블 포함이구요\n하자 전혀 없습니다 네고 사절 이요',NULL,70000,'나주',0,'루나랩 스탠다드 듀얼 모니터암 화이트',4,6),(7,'digital','스피커2개 입니다 길이40센치 살펴보시고 쳇주세요',NULL,10000,'울산',0,'스피커 2개',3,6),(8,'fashion','세탁해서 입양보내요 광주 직거래 원합니다~','2022-08-23 12:40:00.000000',5000,'광주',0,'인형팔아요',14,8),(9,'appliances','\n이사때문에 급하게 내놓습니다.\n사용은 거의 안해서 외부 깨끗 합니다.\n고장 없습니다.\n가죽도 뜯김없이 깨끗한데 \n딱! 등부분만 고양이가 긁어서 실밥부분 조금 뜯김 있습니다. \n코지마 a/s 시트 문의 했더니 139,000원 비용이 드는데 지금 다른 부분은 너무 깨끗하다고 \n아직 교체 하지말고 사용하다가 교체 하는게 좋겠다고 하더라구요. \n사용하시다 시트교체 하시라고 저렴하게 내놓습니다.',NULL,700000,'광주',0,'코지마 안마의자 시스타 쿨거래 네고',6,6),(10,'furniture','사용감 조금 있어요~ 광주 직거래 원합니다!',NULL,150000,'광주',0,'시디즈 T50 의자 팔아요',3,8),(11,'games','중고 100만원 구매해서 \n사용하던 게임기  판매합니다.\n\n전용 좌석, 핸들\n모니터, 음향 괜찮습니다.\n\n나만의 게임방을 꿈꾸시는 분에게 판매하겠습니다.\n\n사이즈가 커서 suv 뒷자리 접어야 실을수 있습니다.\n\n주말에만 거래ㄱㅏ능합니다.',NULL,400000,'여수',0,'플스3  그란투스리모6  게임기 판매',14,6),(12,'beauty','저랑은 조금 안맞는 것 같아서 싸게 팝니다~','2022-08-17 13:45:00.000000',5000,'광주',0,'썬크림 싸게 팔아요',7,8),(13,'etc','철물점 폐업했어요\n인테넷 반값만 받겠습니다\n\n일괄 구매하시는분께는 우대하겠습니다,\n주소:동구 칠전길 70\n\n오후2시부터 판매합니다.',NULL,123,'광주',0,'철물점 폐업물건',7,6),(14,'fashion','뉴발란스 정품 530 모델이에요 \n전체적 상태는 좋구 사용감만 좀 있어요 ~ \n사이즈는 265 이지만 270인데 맞았어요 \n뉴발이 좀 크게 나와서 끈조절만 해도 편했어요 \n상자는 이사오면서 버려서 없네요 ㅜ \n소태역근처 거래 원해용\n편하게 문의 주세용 ^^',NULL,50000,'광주',0,'남성뉴발란스 530판매(사이즈265-270)',12,6),(15,'digital','애플워치 구매후 막상 사용을 잘 안해서 판매합니다.\n케이스 끼고 사용해서 기스하나도 없습니다\n',NULL,150000,'광주 신가동',0,'애플워치 팔아요~',6,7),(16,'beauty','별로 사용 안한 로션 팔아요\n아끼는 물건입니다\n네고 절대 금지','2022-08-17 19:43:00.000000',8000,'광주',1,'더 심플 데일리 로션',37,6),(17,'digital','사용 많이 안한 거의 새상품입니다\n\n아직 고장나거나 문제 하나도 없습니다\n\n박스는 있지만 충전케이블이 없습니다',NULL,170000,'광주 신가동',0,'에어팟 프로 팔아요~',51,7),(19,'appliances','귀여운 냉장고 자취할 때 쓰다가 본가로 들어가게 되어서 팔아요 청소 다해서 안쪽 깨끗합니다.',NULL,120000,'서울특별시',0,'귀여운 파란색 미니 냉장고 팔아요',9,10),(23,'appliances','귀여운 무드등 팔아요\n라이브로 불 들어오는 것도 확인 가능 합니다.\n광주 직거래 선호',NULL,10000,'광주',1,'귀여운 말랑이 무드등 팔아요 ~ 라이브 가능',20,8),(24,'book','상태 S급\n\n네고 가능, 라이브 책 상태 확인 가능\n\n직거래 선호',NULL,100000,'광주',0,'해리포터 시리즈 팔아요',7,8),(25,'sports','손흥민 선수 친필 싸인 축구공 팝니다.\n\n라이브로 인증 가능 합니다\n\n네고 가능 ~',NULL,70000,'광주',0,'손흥민 친필 싸인 축구공',7,8),(26,'furniture','10개월전에 샀습니다\n매트리스는 바디럽 30cm 샀구요\n방수커버 씌웠습니다!!\n\n프레임은 동서가구에서 샀고 전선 연결 잘됩니다.\n\n프레임 분해하려면 드릴이나 드라이버 가져오셔야해요.\n\n같이 옮길 수 있어요 수고비는 아이스크림..',NULL,225000,'부산 동구',0,'침대 슈퍼싱글 매트리스 프레임',3,5),(27,'digital','사용은 많이 안했습니다.\n집에 피아노가 있으면 좀 할 줄 알았는데 안하네요.\n피아노는 흠집없이 깨끗합니다.\n의자는 많이 사용을 해서 사용감이 있어요. 예민하신 분은 피해주시길 바랍니다.\n\n분해하면 suv에 들어갑니다.\n\n부산 동구 수정동 직거래 합니다. 작동 확인하시고 가져가세요. 차에 실어드릴 순 있어요.',NULL,370000,'부산 동구 수정동',0,'kurzweil 디지털피아노 S1F',8,5),(28,'digital','미개봉 인증 라이브로 가능합니다.\n네고 X\n직거래 선호합니다. \n택배 시 택배비 5000원 받습니다',NULL,490000,'광주',0,'미개봉 새제품 삼성 43인치 스마트 모니터 M7 S43BM700',9,8),(29,'furniture','개당 15000원에 3개 있어요 몇번 안썼고 남은 여름 휴가 때 예쁘게 쓰실 분이 가져가시길 원합니다~~',NULL,15000,'대전광역시',0,'인스타 감성 의자로 인생샷 건지세요~~',4,10),(30,'digital','액정, 뒷면 교체받은 새상품입니다\n성능도 아주좋습니다\n거래는 신가동 근처에서만 가능합니다',NULL,300000,'광주 신가동',0,'갤럭시 노트10+ 판매합니다',3,7),(31,'games','상태도 깨끗하고 그립도 짱짱합니다. 고민 끝에 가격 내려서 올립니다. 관련 문의는 쪽지 부탁드려요. 환불은 어렵습니다ㅠ',NULL,550000,'부산 동구 수정동',0,'JAPAN MIZUNO 포지드 남성용 골프채 세트',6,5),(32,'fashion','착용감 있어요\n재질이 좋아서 착용시 그립감이 좋습니다',NULL,5000,'광주광역시',0,'아이폰 13 핸드폰케이스',2,10),(33,'fashion','한번 발만 넣어봤습니다\n사진보다 실물이 더 이쁩니다\n사이즈 300mm입니다\n\n\n거래후 환불은 사절입니다\n잘 확인후 거래부탁드려요',NULL,150000,'광주 신가동',0,'조던 로우 카디널레드 300사이즈 팔아요',7,7),(34,'fashion','응모 당첨된 새제품 입니다!\n편하게 연락주세요~\n\n거래는 부산 동구 내 희망합니다.','2022-08-18 13:32:00.000000',290000,'부산 동구 수정동',0,'나이키 조던 울프 그레이 270 사이즈 팝니다',22,5),(36,'fashion','선물받고 열어보기만한 새상품입니다\n\n실물 상당히 괜찮습니다\n많이연락주세요',NULL,200000,'광주 신가동',0,'마르지엘라 카드지갑 판매합니다',7,7),(38,'fashion','실물 깡패입니다\n\n사이즈는 295mm입니다\n일주일정도 신었는데 생각보다 제발에 커서 판매합니다\n\n자세한건 라이브에서 물어보세요~',NULL,200000,'광주 신가동',0,'나이키 에어포스 미드나잇 네이비',49,7),(39,'games','제 메애기 입니다.\n양육이 힘들어, 입양보냅니다.',NULL,20000000,'전국',0,'떵유 캐릭터 팝니다',54,13),(40,'fashion','범고래 290사이즈 입니다\n\n광주에서 직거래만 합니다\n',NULL,180000,'광주 신가동',0,'나이키 범고래 팔아요~~',4,7),(42,'furniture','4인용 식탁 팔아요\n\n4인용 치고 생각보다 작습니다\n고려해보시고 연락주세요\n직접 가지러 오셔야합니다',NULL,70000,'광주 신가동',0,'4인용 테이블 팔아요',2,7),(43,'etc','개당 2천원\n50개정도 있습니다\n회로작업 많이하시는분들 싸게 가져가세요',NULL,2000,'광주 신가동',0,'납땜작업용 납 팔아요',4,7),(44,'games','총 250만원정도에 맞췄습니다.\nCNK 중량봉\n몬스터블럭 16장\n인벤탑 랙\n바레타 벤치\n\n로버스트 원판\n20kg x 4\n10kg x 2\n5kg x 2\n2.5kg x 2\n1.25 원판 두개는 서비스로 드려요\n\n용달 트럭 가져오셔야되구, 가져가시기 편하도록 분해해드립니다. 트럭에 같이 실어드릴 수는 있어요.',NULL,1200000,'부산 동구',0,'홈짐 풀세트 팔아요',4,5),(45,'appliances','제습기 판매합니다\n성능 좋아요\n\n소음이나 자세한 사항 라이브에서 물어보세요',NULL,100000,'광주 신가동',0,'제습기 팔아요~',2,7),(46,'games','샀는데 노래를 너무못불러서 그냥팔려구요\n에코조절, 음성변조도됩니다',NULL,50000,'광주 신가동',0,'블루투스 마이크 팔아요',6,7),(47,'etc','아메리카노 톨사이즈 쿠폰 여러장있습니다\n',NULL,3000,'어디든',0,'스타벅스 기프티콘 팔아요',5,7),(48,'digital','19년도 그램입니다\nCpu : i5 8세대\nRam : 8g\nssd : 256gb\n구성품 : 노트북 + 충전기\n\n17인치 그램을 새로 구매해서 기존 사용하던 14인치 그램 판매해요. 윈도우 11 pro 정품 설치돼있고, pc초기화 + ms 계정 로그아웃해서 바로 이용하실 수 있도록 세팅해놨습니다.\n\n기본적인 사용감은 있지만, 책상 위에만 올려두고 조심스럽게 써왔습니다. 거래는 부산 동구 수정동에서 하며, 평일 12시-13시 / 6시 이후 가능합니다.',NULL,650000,'부산 동구 수정동',0,'19년 그램 14ZD990-GX50K',3,5),(49,'digital','버미어5600\nrtx3060 장착중입니다\n\n자세한사항과 게임구동은 라이브때 만나요',NULL,1000000,'광주 신가동',0,'데스크탑 게임용 본체 팔아요',3,7),(50,'digital','브라운9 시리즈 9395cc 크롬 색상 판매합니다. 올해 9월에 구입했는데 날면도만 해서 팔아요. 3회정도밖에 사용하지 않아서 새상품이나 다름없습니다.\n\n구성품 : 전기면도기, 세척스테이션, 세정액 5개, 면도기 케이스\n\n부산 동구 수정동에서 직거래 합니다. 연락 주세요 :)',NULL,250000,'부산 동구',0,'브라운 전기면도기 9395cc 크롬 팝니다 브라운 전기면도기',3,5),(51,'book','외환전문역 2종 기본서 최신판 3종세트 팝니다. 한국금융연수원 홈페이지에서 6월 3일에 구매했구요. 배송 온 그대로 개봉 없이 보관하고 있습니다. 거래는 부산 동구 수정동에서 합니다.',NULL,40000,'부산 동구',0,'외환전문역 2종 기본서 외전역',6,5),(52,'digital','이번에 부품 업그레이드하면서 내놓습니다\n\n롤피파서든 정도의 게임을 원하는분이면 아직 괜찮은 성능이라고 생각합니다.\n\n원하시면 구동영상 라이브에서 보여드릴게요',NULL,90000,'광주',0,'i5 7500 cpu판매합니다',3,7),(53,'digital','로지텍 무선마우스 g304입니다\n\n성능에는 문제없고 몇달 잘써먹었습니다\n중고상품이니 가볍게 사용하실분만 연락주세요',NULL,20000,'광주 신가동',0,'로지텍 무선마우스 팔아요',2,7),(54,'fashion','사이즈는 270mm입니다\n\n상세히 보고싶으신분 라이브요청 눌러주세요~',NULL,230000,'광주 신가동',0,'나이키 조던 스텔스앤화이트',4,7),(55,'fashion','3장 합쳐서 20만원에 판매합니다.\n개별 구매하시면 장당 75000에 팔아요.\n직접 오픈런 뛰어서 사 온 제품입니다. 사이즈는 세 장 모두 XL 입니다.\n부산 동구 수정동에서 직거래 합니다.',NULL,200000,'부산 동구',0,'Iab studio 카카오 콜라보레이션 티셔츠 3장 팝니다.',8,5),(56,'etc','어려서 아직 울타리 신세입니다. 귀엽죠?',NULL,1,'부산 동구',1,'귀여운 강아지 보고가세요',19,5),(57,'etc','6개월 교육받아 받은 상품입니다\n',NULL,1000000,'광주',0,'싸피 수료증 팔아요~~',50,7),(58,'beauty','절반정도 사용했습니다\n\n만나서 시향만 하고 구매 안하시면 안됩니다',NULL,50000,'광주 신가동',0,'구찌 길티 남자 향수 팔아요',6,7),(60,'sports','농구 같이할 사람이없어서 재미없어서 팔아요\n\n아니면 농구하실분 구함',NULL,35000,'광주 신가동',0,'농구공 팔아요',8,7),(61,'sports','오른손잡이용입니다 (왼손에 착용가능)\n\n야구장가서 홈런볼 파울볼 잡아보겠다고 샀는데 제가 있는곳으로 공 절대 안오네요\n필요없어서 팔아요',NULL,50000,'광주',0,'야구 글러브 팔아요',11,7),(62,'sports','싸게드려요 한 개 사시면 한 개 더 드려요 1+1~',NULL,3000,'광주',1,'야구공 팔아요',7,15),(63,'sports','운동하다 귀찮아서 팔아요~~~',NULL,50000,'광주',0,'운동 기구',11,17),(64,'digital','구매는 6개월 전에했습니다\n깔끔하게 사용해서 액정 엄청 깨끗합니다\n',NULL,100000,'광주',0,'갤럭시워치3 판매합니다',13,7),(65,'furniture','가로120 세로60 사이즈입니다\n컴퓨터책상, 공부용 책상으로 딱입니다\n다리가 높이조절도 되서 본인이 편한 높으로 조절가능합니다\n직접 가지러 오셔야합니다',NULL,60000,'광주',0,'이케아 책상 판매합니다',10,7),(66,'appliances','팔아요\n네고는 없어요',NULL,10000,'광주',0,'헤어드라이기',13,6),(68,'fashion','귀여운 아보카도 인형 팔아요',NULL,5000,'부산광역시',0,'아보카도 인형 팔아요',3,10),(69,'book','완전 새거라고 보시면 됩니다\n사용감 없어요 표지도 깨끗해요',NULL,20000,'광주광역시',0,'열역학 책 팔아요',5,10),(70,'book','표지에 사용감 살짝 있어요\n안에는 흔적 하나도 없고 깨끗합니다',NULL,10000,'광주광역시',0,'전자기학 책 팝니다',3,10),(71,'digital','갤럭시 워치 편하고 좋아요\n얼마 안썼는데\n40mm 선물받아서 42mm 팔아봅니다\n사용감 없어요 2주정도 착용했어요',NULL,250000,'제주특별시',0,'갤럭시워치4 42mm 팔아요',11,18),(72,'appliances','비교적 옛날 모델이고 많이 사용해서 싸게 팝니다\n아직 작동 잘되고 불만 없이 사가실 분들만 연락주세요\n네고 가능합니다 직접 가져가셔야해요',NULL,30000,'서울특별시',0,'청소기 팔아요',3,18),(73,'appliances','스팀도 나오고 되게 좋아요\n자취하시는 분들 새거 사지 마시고 어차피 본가 가시면 버릴거니까\n좋은거 싸게 사가세요',NULL,15000,'경기도 수원시',0,'다리미 싸게 가져가세요',2,18),(74,'fashion','뒷꿈치 까짐 조금 있어요\n라이브로 확인 가능합니다\n엄청 조금이고 나머지 상태 양호합니다\n사이즈 230 인데 225인 분들이 신어도 안헐렁거려요',NULL,25000,'강원도 횡성군',0,'컨버스 하이 팔아요 230',9,18),(75,'book','표지에 기스 있는데 하드케이스라 안쪽에 아무 문제 없습니다\n안쪽은 낙서 하나도 없고 깔끔합니다\n한장 한장 다 보여드려요',NULL,20000,'제주특별시',0,'양자역학 고양이책 팔아요',4,10),(76,'fashion','어피치 베이비 인형이예요\n바디필로우 처럼 말랑하고 세탁해놨습니다',NULL,9000,'전라북도 부안군',0,'애기어피치 러피치 인형 팔아요',5,10),(77,'fashion','춘식이 인형이고 길이는 팔뚝정도 길이예요 애기들이 가지고 놀기 좋아요',NULL,9000,'서울특별시',0,'춘식이 인형 팔아요',5,10),(78,'etc','10마리 있고 일괄 만원입니다\n제가 아는 분이 직접 양식 하신 거라 맛은 보증합니다\n한 솥 구워먹었는데 많이 남아서 근처 사시면 사가시면 좋겠습니다',NULL,10000,'전라북도 정읍시',0,'싱싱한 전복 직거래합니다 10마리',12,10),(79,'appliances','제 덩치랑 안맞아서 팔아요',NULL,5000,'전남 해남군',0,'책상용 미니 선풍기 팔아요',3,7),(80,'digital','겉모습은 사용감이 좀 많있습니다\n그래픽카드 1060사용중입니다\n\n제 주변에 코딩 좋아하는 사람들이 많이 사용하는 노트북입니다\n\n가벼운 게임도 잘 돌아갈겁니다\n저는 안해봤습니다',NULL,1000000,'광주 하남산단',0,'삼성 노트북 팔아요~',3,7),(81,'appliances','1년정도 사용했습니다\n\n소음 별로 안시끄럽고 빛을 자동으로 감지하는 수면모드도 있습니다\n\n라이브때 소음과 작동방법 설명해드릴께요',NULL,100000,'전남 해남군',0,'공기청정기 판매합니다',3,7),(82,'book','거의 새책입니다\n\n이거 구매하신분 무조건 다이렉트로 실시까지 합격하실겁니다',NULL,10000,'광주 수완동',0,'정보처리기사 필기 책 팔아요',5,7),(83,'appliances','이사를 가게 되었는데 티비를 새로 구매하게 되었습니다\n\n구매한지 6개월 정도 된 스마트tv입니다\n\n라이브 요청하시면 넷플릭스, 유튜브로 화질과 선명함을 느낄수 있게 해드리겠습니다\n직접 가지러 오셔야합니다',NULL,1400000,'광주 신가동',0,'삼성 65인치 TV 판매합니다',8,7),(84,'appliances','용량 생각보다 커요\n\n청소하기 쉽게 분리가 되도록 설계되어 있습니다\n기름이 많은 음식해도 뒷처이 걱정안하셔도됩니다',NULL,50000,'경기도 연천군',0,'에어프라이어 판매합니다',2,7),(85,'appliances','생각보다 작아요\n서브용으로 쓰시거나 1인가구이신분이 쓰기 좋을것같습니다\n\n직접 가지러 오셔야합니다\n라이브 요청시 안에 들어있는 아이스크림 먹방 보여드리겠습니다',NULL,300000,'광주 신가동',0,'냉장고 판매합니다',4,7),(86,'digital','이어폰 새로 구입해서 판매합니다\n\n기스만 살짝 있고 아직 쓸만해요',NULL,70000,'용인시 기흥구',0,'갤럭시 버즈팔아요',2,7),(87,'digital','동글이 연결해서 블루투스 연결 됩니다\n\n화질 괜찮아여 \n라이브 요청하면 영화한편 틀어드립니다\n',NULL,50000,'광주 서석동',0,'빔프로젝터 팔아요',3,7),(88,'fashion','조기 축구 하려고 샀는데 몇번 못나가서 팝니다.\n사이즈는 265mm입니다.',NULL,15000,'서울특별시',0,'축구화 팔아요 265mm',4,10),(89,'furniture','철제 수납장입니다\n\n용량이 커서 생각보다 수납 많이됩니다',NULL,100000,'광주 용봉동',0,'이케아 수납장 판매합니다',3,7),(90,'sports','과녘 종이입니다\n1장에 2000원이고\n10개있어요',NULL,2000,'광주광역시',0,'양궁 놀이 과녘 팔아요 10장있습니다',3,10),(91,'digital','기존 박스에 그대로 포장해두었습니다\n외관 기스 하나도 없습니다\n\n라이브 요청시 작동영상, 외관 자세히 보여드립니다\n원하는 게임 있으면 플레이영상 보여드립니다',NULL,500000,'광주 운암동',0,'갤럭시 탭 S7 팔아요',2,7),(92,'beauty','매니큐어 8개 세트로만 팔아요\n노란색만 한번썼고 나머지는 안썼어요~',NULL,20000,'경기도 용인시',0,'매니큐어 8개 세트로만 팔아요',8,10),(93,'etc','넓은 건물입니다\n친구들 4명이서 놀러가는거 추천합니다\n\n스키장 근처라 아껴뒀다 겨울에 가셔도 됩니다',NULL,90000,'무주',0,'무주 펜션 이용권 양도합니다',6,7),(94,'digital','케이스 끼고 사용해서 엄청 깨끗합니다\n액정필름 새것도 같이 드릴게요',NULL,100000,'서울특별시',0,'갤럭시 핸드폰 팔아요',4,10),(95,'digital','연식이 좀 되어서 싸게 팝니다\n디카 감성 좋아하시는 분들 사가시면 좋아하실거라 생각합니다',NULL,50000,'부산광역시',0,'삼성 디지털 카메라 팔아요',3,10),(96,'appliances','장마철에 빨래하기 힘드시죠\n\n건조기있으면 빨래가 힘들지않아요\n뽀송뽀송하게 말려줍니다\n먼지도 잘 빨아먹습니다\n\n라이브 요청하시면 빨래하러갑니다',NULL,500000,'광주 신가동',0,'삼성 건조기 판매합니다',3,7),(97,'etc','개당 5000원입니다\n아두이노로 가벼운 회로 짤때 사용하려고 샀는데 안써서 판매합니다',NULL,5000,'광주 신가동',0,'적외선 센서 판매합니다',4,7),(98,'etc','개당 2500원입니다\n너무 많이 사서 팔아요!\n개봉 안한 새 상품들입니다',NULL,2500,'광주광역시',0,'누텔라 새거 5개 팔아요',3,18),(99,'etc','블루투스 연결 잘됩니다\n아두이노로 간단한 회로 만들때 사용하시면 됩니다',NULL,4000,'광주 신가동',0,'블루투스 모듈 팔아요',2,7),(100,'digital','새상품입니다. 꺼내서 인증샷만 찍었어요!\n라이브로 상태 확인 가능합니다!','2022-08-18 16:53:00.000000',500000,'서울 왕십리',0,'갤럭시플립 3 새상품 판매합니다',23,1),(101,'digital','새상품입니다. 꺼내서 인증샷만 찍었어요!\n라이브로 상태 확인 가능합니다!',NULL,500000,'서울 왕십리',0,'갤럭시플립 3 새상품 판매합니다',8,1),(102,'games','상태 최상이구요\n모든 조각 다 있습니다\n이 상태 그대로 전달도 가능 합니다',NULL,10000,'대전광역시',0,'원피스 퍼즐 팔아요',3,18),(103,'etc','카카오뱅크 스티커 리미티드 에디션 팔아요 카카오프렌즈 성형 전이라 비쌉니다 뜯지도 않았고 상태 최상이예요',NULL,100000,'부산광역시',0,'카카오뱅크 스티커 리미티드 에디션',4,18),(104,'fashion','일본에서 사온 포켓몬 인형 팔아요 완전 때 하나도 안탔고 상태 최상입니다',NULL,15000,'강원도 횡성군',0,'포켓몬 인형',5,18),(105,'fashion','두개 세트구요 7000원 입니당\n완전 귀여워요\n원숭이 포즈 바꿀 수 있습니다\n라이브에서 보여드릴게요',NULL,7000,'대구광역시',0,'원숭이 인형 팜',5,18),(106,'fashion','문어 인형 팔아욧',NULL,3000,'광주',0,'문어 인형 개당 3000',6,20),(107,'games','용쿠',NULL,3000,'광주',0,'용쿠 띠부띠부씰 팔아요',4,20),(108,'fashion','연극 무대에도 올라갔던 대배우\n에눌 ㄴ\n',NULL,50000,'인천',0,'안소니 양도해요',13,19),(109,'games','우리 애긔 잘 데려가 키워주세요',NULL,8888,'광주',0,'커피나무 새싹',4,20),(110,'fashion','국립고궁박물관에서 튀어 나온듯한 떨잠. 나비가 살아움직이는듯한 능동성이 느껴지지 않나요.',NULL,600000,'서울',0,'떨잠 팔아여',4,20),(111,'book','세기의 천제 니체의 차라투스트라는 이렇게 말했다! 앞의 5장만 10 번 읽고 나머지는 깨끗해요^^',NULL,7000,'광주',0,'차라투스투라는 이렇게 말했다 팔아요 상태 상급',6,20),(112,'etc','★SSAFY 합격 자소서★\n\nSSAFY에 대한 정보가 너무 없어서 막막하신가요?\n자소서를 어떻게 써야하는지 감도 못 잡으시겠다구요?\n면접 기출 문제가 궁금하신가요?\n\n그 궁금증 모두 제가 해결 해드리겠습니다!\n\n라이브방을 통해 견적 확인해드립니다.\n최신 정보 반영 100% 신용 100%',NULL,5000,'ANYWHERE',0,'★SSAFY 합격 자소서 / 자소서 첨삭 / 면접 꿀팁 / 싸피 꿀팁★',11,19),(113,'beauty','따끈따끈한 신상템이에요',NULL,300000,'광주',0,'코로나 팔아요',17,21),(114,'etc','중국의 맛을 중국집보다 잘 느낄 수 있는 맛',NULL,12000,'광주',0,'중국산 컵밥 컵라면 ㅍㅍ',5,20),(115,'beauty','밝은색만 조금 썼어요\n단품 섀도우도 하나 서비스로 드려요!!',NULL,9000,'광주광역시',0,'맥 4구 섀도우 팔레트 팔아요',3,18);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_img`
--

DROP TABLE IF EXISTS `product_img`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_img` (
  `pid` int NOT NULL AUTO_INCREMENT,
  `path` varchar(255) DEFAULT NULL,
  `no` int DEFAULT NULL,
  PRIMARY KEY (`pid`),
  KEY `FKd522x5gcs28uwdaa49usk3bkr` (`no`),
  CONSTRAINT `FKd522x5gcs28uwdaa49usk3bkr` FOREIGN KEY (`no`) REFERENCES `product` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_img`
--

LOCK TABLES `product_img` WRITE;
/*!40000 ALTER TABLE `product_img` DISABLE KEYS */;
INSERT INTO `product_img` VALUES (1,'/images/productImg/Wl1yZd0Z6xl0Eiznk3wc4XjLduEIk2yy.jfif',1),(2,'/images/productImg/4B9NSveEJACbBVV29EyQkzLbwvHAFngX.jfif',2),(3,'/images/productImg/0ziZD8VKxNsyqcHwdyoCssh31p5b0Bmj.jpeg',3),(4,'/images/productImg/TnU4aRKZT8FjLQt87zxZzBW14fYjlpJL.jpeg',3),(5,'/images/productImg/uQJUqXCIsPFuLYRQqVa1e3sQQ9DGzouo.jpeg',3),(6,'/images/productImg/qJLTAVLWSRm615oxNcd2dSoOsWmeFgtZ.jpg',4),(7,'/images/productImg/0nDB9vcAPGT92hxy77jN8apUDgEJJQgx.jpg',5),(8,'/images/productImg/DyWDcQ2JfoLhpUrAdfbPB2855094RJYU.jpg',6),(9,'/images/productImg/PCyeY28psXHURqcBjP875oXQY13xVh4i.jpg',6),(10,'/images/productImg/NLa1DNaL5njYhMwIHhORTfI9nbA6XW3d.jpg',7),(11,'/images/productImg/HRCN7abwgTKwyo0xKEVAaqO3KGPTT55s.jpg',7),(12,'/images/productImg/8hB54V72TxFCzXSzBytz89AZwXESZ1oN.jpg',8),(13,'/images/productImg/vJYMZwShfttDyVEramw9X9o938wQQwzx.jpg',9),(14,'/images/productImg/QkqD3aCp361ohv13W2kptbK01e5vfH62.jpg',9),(15,'/images/productImg/0J9iZ7mliLk3OxyJ9nulaYfYvANoxVKM.jpg',9),(16,'/images/productImg/yMzWXLLJKnpK2X6WvNN9OgqypDOqQdo2.png',10),(17,'/images/productImg/D0w7Y2RbnE83GI2xrLTrsL5EYTnTw7cI.jpg',11),(18,'/images/productImg/6ZTwHsWmWz1fXeytqyVoLM4ZDoRUtjSy.jpg',11),(19,'/images/productImg/TK9GcoaufrhYgVQRDe84HO2NTD1ajiRi.jpg',12),(20,'/images/productImg/pLiI5t3CzItr9RxwuuZwqmkMq2g0dWM7.jpg',13),(21,'/images/productImg/xkVq9USjtm98v56olSuDvyXBNI94Egnt.jpg',13),(22,'/images/productImg/wMUwSwtDEvRMRutpqgcJhr04EF7gvHnK.jpg',13),(23,'/images/productImg/xh7esrTbKV67KWJAvnRtQ5uL2Esz66lm.jpg',13),(24,'/images/productImg/BnCVd0peRfcvyE0gY7kOXAydFhUOF9y7.jpg',14),(25,'/images/productImg/4FCiG6BPAqbFgQtmnitGSjtgO67fNFux.jpg',14),(26,'/images/productImg/vfMU6NCblzxjnJyla6Njvb89J5PYbIhv.jpeg',15),(27,'/images/productImg/r9FtNenKML90Vy2MLFoKpFHfBzDDI972.jpeg',15),(28,'/images/productImg/ODcTI4bunJQrtlzNTxv74tmCa3a6TDcl.jpg',16),(29,'/images/productImg/S1uQQJIGn6FMtCOJXCRuvqZf4oDbHyuQ.jpeg',17),(30,'/images/productImg/uEqD56gOUPTDE1SXFu46yeEyRRZyRum2.jpeg',17),(32,'/images/productImg/IRkvno6qwpBDV2UBs6uqbsdx6FOWe58v.jpg',19),(36,'/images/productImg/bN0MMHACdaCe5EnANjJ51QIn3Lg9FTni.jpg',23),(37,'/images/productImg/BZOSPiF2aPhjB1ER9niibXgxRBoukWPP.jpg',24),(38,'/images/productImg/o9Jz4kXouhS2I5DauUxz2jnnRHYXJvN3.jpg',25),(39,'/images/productImg/YiChTn11FTyEmtA4WkvLPky6UbZIKsjf.jpg',26),(40,'/images/productImg/XrnVnoAi2Ohw4XIiYsR35nsshMrPWJR7.jpg',26),(41,'/images/productImg/VhWvcmmUfhMYsbmiiL2ckxvTjtBHsnTl.jpg',27),(42,'/images/productImg/R8Juv5YgggQNVJYMV2hoiRGofbDe9oEx.jpg',27),(43,'/images/productImg/L94qq7B3HVZUsCGDhWPplGw59FZEfDwu.jpg',28),(44,'/images/productImg/rreBKymoAjKUkmQyEsUFXyAtu1ZP2o9M.jpg',29),(45,'/images/productImg/OpRS8rUESOf10zmi9nxqiua9Ad5ZJy3G.jpeg',30),(46,'/images/productImg/Zig2NlBxRaSGmksA9nd9ZCBowjyCrpsV.jpeg',30),(47,'/images/productImg/yMHZPtC5itAvRWGPSnSfi8OYeUYAuiC3.jpg',31),(48,'/images/productImg/OP4cpjhuSF931lGpVUaKcR7REYP7v8Jn.jpg',31),(49,'/images/productImg/uEdZOGpWheFqisKfWQGIiRT8llTLDvKk.jpg',31),(50,'/images/productImg/LYAH0JvDTOPCILfSS6jX3t2kjJZXCZZf.jpeg',32),(51,'/images/productImg/2YXKHWFGgd96HuFmxREnoVaYZXZFK73i.jpeg',33),(52,'/images/productImg/6DOHpIKs0OPNskRYb4HCmVuLUkCK5OXY.jpg',34),(53,'/images/productImg/DNVlADDsjrLIKletQfQNR8nQYn98l9OI.jpg',34),(55,'/images/productImg/vDID437stqiLNHmoYnVnBWUF4iNpdN2f.jpeg',36),(57,'/images/productImg/GWsNZY5bRoJIPaDu3iOtwxmH4nnrYN8o.jpeg',38),(58,'/images/productImg/mkqC25G5QAULufMEYuYPuj3YWscxMrwZ.png',39),(59,'/images/productImg/1TEhDrxlHKfa3KopsmSa0EaEX5Je0ZYu.jpeg',40),(60,'/images/productImg/tsMnl958EeqzLsF5mhsAtRpfXF4dkRob.jpeg',40),(62,'/images/productImg/DxC2u0uW7QLRVjJ6wCoHGM43RPiUVLuE.jpeg',42),(63,'/images/productImg/v6xyjkwkabBAYN3d9HOYNl6atfjjKmYq.jpeg',43),(64,'/images/productImg/PceMVgM0daPHT2kewG4PzAyqLcKaPTJi.jpg',44),(65,'/images/productImg/REgQn8k7gKQ6s5AWuT7ZyR6GyMb9QYTM.jpg',44),(66,'/images/productImg/WwtH5zgzcu8RbTUNfney8O5my00NHTAe.jpg',44),(67,'/images/productImg/1WJsTk95JwJQIlUYHM9QXTutIlHye6ym.jpeg',45),(68,'/images/productImg/FUOt0l7IqMDBTJuq6W8uKKGwByCS47wR.jpeg',46),(69,'/images/productImg/le8XrNy4sZnOzTVRlh0na7IkxJ6ceXsQ.jpeg',47),(70,'/images/productImg/d4zU7jukQparN59Z3bYUxOD3wL0NbJKN.jpg',48),(71,'/images/productImg/vNKeCEfO06o0nmoFEO32AeZbAMQNt5M9.jpg',48),(72,'/images/productImg/eMSRdFUnZ49CpTJyGQs5lmu2TLoeP9ds.jpg',48),(73,'/images/productImg/StqG7Ukib1EXtfxLI4i1HtSYyFzzkbdZ.jpg',48),(74,'/images/productImg/0WNFVJuH9hRffm7Bovc4xV1EcNeW8beR.jpeg',49),(75,'/images/productImg/DzmLlTXCBzD03dGNU4b0pVk4XmdYlfSU.jpg',50),(76,'/images/productImg/xCNLDC4CIKFxzXh6nJGeC1fbRpR2mXdo.jpg',51),(77,'/images/productImg/7mrktkmzOJkDdPDCZTZHx53fJuWLBs0i.jpeg',52),(78,'/images/productImg/fMm2K5ZYTklVoVxwrGNVTUWpY7B6f7VI.jpeg',53),(79,'/images/productImg/KcRBo25RZ0EMfrrlGg1YGyYZS0ZrpN7t.jpeg',54),(80,'/images/productImg/vbAfqaTPp6GlWfCn0r2GcAvcF66MamuT.jpeg',54),(83,'/images/productImg/cpK5RkLCWcHKcL715UrI5lzC84nWJrCC.jpg',55),(84,'/images/productImg/May9hCmccu73DVoSrMQiDhaj62ywq3dd.jpg',56),(85,'/images/productImg/k3akXiYC1yAtDxL0MJpZpdIAjggQWLNy.jpg',56),(86,'/images/productImg/iPjYjjaXvj7oedbjgUbnbdzNq7w29nBQ.jpg',56),(87,'/images/productImg/J2743f69C1Xyrgg0QsUbeZ3ngp22dh7e.jpg',56),(88,'/images/productImg/NRawOYfjvbU1Il36v6nkP7gIintUayr1.jpeg',57),(89,'/images/productImg/VY9sihEDAlJx3uSIymIe1jrOMJzNWdjQ.jpeg',58),(92,'/images/productImg/1wpdA5MlrMPqV1JuCXGSAKJKnRHRR2oi.jpeg',60),(93,'/images/productImg/PkGuurGxJeIAh3qqN9vqSzsGcONd04Jl.jpeg',61),(94,'/images/productImg/hhULtUT0mm9lzkGnREvQIsLx0O63v5OA.jpg',62),(95,'/images/productImg/KfG56dQtQO0s9NrjpN3CMtb0evnt1mLX.jpg',63),(96,'/images/productImg/JX77fdEDJh87ZEPzB3d165eNr4ro2GEP.jpeg',64),(97,'/images/productImg/TNayz8aQn5xfygnLXm9NsOxydB25Ij7P.jpeg',64),(98,'/images/productImg/CquUGNZ4mp5qvw7sIamXS7aKJE2SWrEX.jpeg',65),(99,'/images/productImg/YkvvvUiaJLcHpkYsuENz18HjoJkR7r9X.jpg',66),(101,'/images/productImg/uEOHyMFDoXqvsum7kyCcebBkKNPqjTlX.jpeg',68),(102,'/images/productImg/7cQdVDaAlPCnIdvHIvz2GpcliYyIzuHr.jpeg',69),(103,'/images/productImg/Iow3IKhNeUvqMQYYzmcpH8kQhcXBVo1F.jpeg',70),(104,'/images/productImg/e7cjcv0dIvZkyoRSWnFzjCNvov6jn3Wh.jpg',71),(105,'/images/productImg/09x8niBzqhPVK8W5F00dbYJAaCKMeO0W.jpg',72),(106,'/images/productImg/9nKRI0Ynzy7yDoO3jFe5QiOdUN2boujZ.jpg',73),(107,'/images/productImg/al3K5kkJ0AD0Sc6oeqtxu96c29ClY4BK.jpg',74),(108,'/images/productImg/LdGCGbmD5aOL3V2f9ghlbtzCFkPDZljO.jpeg',75),(109,'/images/productImg/cbQp9BBWUcyseB0iKOg5GN4e5AdYEDGE.jpeg',76),(110,'/images/productImg/lqiIdakJSiERlWvxkJ4CQWjPEdbA7Rfz.jpeg',77),(111,'/images/productImg/rHnAgRfVVxagDVPG5lgmx39rpYfK161Q.jpeg',78),(112,'/images/productImg/u4XKu1pO3ktboEpBam4Ah5HZUKjAkSaF.jpeg',79),(113,'/images/productImg/Wc5NSes58YFbmLzn9iBzO4N1CH7OiIFx.jpeg',80),(114,'/images/productImg/fRbDxvUOC6f6dPtsC6gFifgkiEL0tx0U.jpeg',80),(115,'/images/productImg/PSVGbTQHRVxDXzeCTXWrfzl2u5XQ8qcT.jpeg',81),(116,'/images/productImg/eISpivWu266dqLifNg3ixy3LVYVAKAz2.jpeg',82),(117,'/images/productImg/BZ8EmUpw9axedB38CK5eoibyJyreltyu.jpeg',83),(118,'/images/productImg/uFUSIKJImLnLFpZBZ29Om89AdfwtncRi.jpeg',84),(119,'/images/productImg/Qwo1Wq7LFC3GnpUcDhRivtSNeD2Ec87M.jpeg',85),(120,'/images/productImg/sfjvNiBKU242kuVI8RaU2v8a6XUPsA7r.jpeg',86),(121,'/images/productImg/KssR9NSeCRD6FLxiL6VYw34aMJX9AILb.jpeg',87),(122,'/images/productImg/AvLBjPEKe6Qs2AKM82jkfchEXi1tdVRn.jpg',88),(123,'/images/productImg/Kc2OyMPn9FHdi5v8T5QIfOyJP9NYzUqQ.jpeg',89),(124,'/images/productImg/CNmCdwR9guPAHMljgUFq6aEVlbWCEAVf.jpg',90),(125,'/images/productImg/6GxyYOG1GjkathNzKaCMx7INEw3PWRtz.jpeg',91),(127,'/images/productImg/7Au7BQKxqvbiQJbs9axDfxXnLNpJiDOf.png',92),(128,'/images/productImg/HjlWi51sutrXnsw1VDteYLABQqA0mpk8.jpeg',93),(129,'/images/productImg/thtyqHrXIkqeukZZdCK5sXqs75meSt8M.jpg',94),(130,'/images/productImg/YnioROqIfXmR4Y1bj8fero0dvocsC40O.jpg',95),(131,'/images/productImg/SHTiLjLyPvYoEmFp0ZFzZWfP56MSsd5E.jpeg',96),(132,'/images/productImg/bSUuvKi0gGtjBbEAGFlMTPKuuIhj2kKu.jpeg',97),(133,'/images/productImg/VkgwUsRYelGt32rH4BlDoLQbRWtf2yb0.jpeg',98),(134,'/images/productImg/DiXSeXsSygeqpkaDSKMADSDLOasX33y0.jpeg',99),(135,'/images/productImg/ODQUKp1XdE24nUZqEBZlzkDehLqpaXXl.jpg',100),(136,'/images/productImg/nzOMHpGCRAKsUL9xUuNuQHf5HTT41i0E.jpg',100),(137,'/images/productImg/w6SCXORH0Ecw2iq4iMPBxIULiprs2jpg.jpg',100),(138,'/images/productImg/5R32xZFhY8Jg1dro2ZvReZafFaK79hty.jpg',101),(139,'/images/productImg/5LmhyOKKSKME4Skj5yBrUcj9T2MxDCRO.jpg',101),(140,'/images/productImg/vRdkCGlwKjt5HRAu7W0igmqWXR6g9sr8.jpg',101),(141,'/images/productImg/Qd2vLPlxIqtjWTAikAPFYCbUPFfN9NVQ.jpeg',102),(142,'/images/productImg/P5BiIaaDzOhyULAwUdZBxrHaxUWl2LGz.jpeg',103),(143,'/images/productImg/2ZBEsmMCKqHpXBTXLDfoJqhdYzpH8DRz.jpeg',104),(144,'/images/productImg/i2A7XGvurw6agQKWUlNI1tbuhFbInvIE.jpeg',105),(145,'/images/productImg/KFW7sdaNjfl0ah9ePq0cBgVfuXzC18BL.jpg',106),(146,'/images/productImg/NoXiBXk48VoccEZPhdwn0LQS8n7AXIOe.jpg',107),(147,'/images/productImg/JOzkA7epExKqSiJZhDmeBqEPjmZxzXKq.jpg',108),(148,'/images/productImg/p5lfLtAuizeDgWZoRePe9T93g2PXAIp7.jpg',109),(149,'/images/productImg/BxtT7yZ0PdbraUzatsnwB2yvJ4jPVuiY.jpg',110),(150,'/images/productImg/maS8I7veZzvKkjzFhrjpNtPIIg8mqM7n.jpg',111),(151,'/images/productImg/LtjGi45GEy183h6FmdIjSzkZTYTpLWUq.png',112),(152,'/images/productImg/PZODvs0XdO93xpjYgYKB1FoI48VqF9uY.jpeg',113),(153,'/images/productImg/0iRSSJueZpfapDZHherACcLXWwsOELVi.jpg',114),(154,'/images/productImg/OCFWDUJZbbCyEHoNMuabP2Dm4EYSJ17s.jpg',115);
/*!40000 ALTER TABLE `product_img` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `request`
--

DROP TABLE IF EXISTS `request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request` (
  `request_id` int NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) DEFAULT NULL,
  `userid` varchar(255) DEFAULT NULL,
  `no` int DEFAULT NULL,
  `user_pk` int DEFAULT NULL,
  PRIMARY KEY (`request_id`),
  KEY `FK21pmulsthu3ihkocip0p8leui` (`no`),
  KEY `FK8rbmtvb32i1qxlr3tbwnpfk9d` (`user_pk`),
  CONSTRAINT `FK21pmulsthu3ihkocip0p8leui` FOREIGN KEY (`no`) REFERENCES `product` (`no`),
  CONSTRAINT `FK8rbmtvb32i1qxlr3tbwnpfk9d` FOREIGN KEY (`user_pk`) REFERENCES `user` (`user_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `request`
--

LOCK TABLES `request` WRITE;
/*!40000 ALTER TABLE `request` DISABLE KEYS */;
INSERT INTO `request` VALUES (2,'떵유','ehddb2252',28,13),(3,'yuzu','yuzu1',17,10),(4,'yuzu','yuzu1',11,10),(7,'솔드솔브','soldsolve',23,15),(8,'이만득','alswo96',16,17),(9,'사용자닉네임','user',63,3),(10,'이만득','alswo96',5,17),(11,'이만득','alswo96',66,17),(12,'사용자닉네임','user',39,3),(13,'yuzu','yuzu1',57,10),(14,'solsol','soldsolve',61,15),(15,'yuzu','yuzu1',58,10),(16,'yuzu','yuzu1',100,10),(17,'김싸피','김싸피',100,5),(18,'yuzu','yuzu1',101,10),(19,'햄솜','haengsong',100,7),(21,'yuzu2','yuzu2',100,18),(22,'너납치된거야','너납치된거야',100,12),(23,'yuzu2','yuzu2',46,18),(24,'yuzu2','yuzu2',112,18),(25,'햄솜','haengsong',112,7),(27,'ssafy','ssafy',113,20),(28,'ssafy','ssafy',105,20),(29,'모아이','dlalswo9801',101,6),(30,'모아이','dlalswo9801',100,6);
/*!40000 ALTER TABLE `request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `review_id` int NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `score` double NOT NULL DEFAULT '3',
  `reviewee_id` int DEFAULT NULL,
  `reviewer_id` int DEFAULT NULL,
  PRIMARY KEY (`review_id`),
  KEY `FKrxxkeo5xlq721tgwpnyfx326i` (`reviewee_id`),
  KEY `FKt58e9mdgxpl7j90ketlaosmx4` (`reviewer_id`),
  CONSTRAINT `FKrxxkeo5xlq721tgwpnyfx326i` FOREIGN KEY (`reviewee_id`) REFERENCES `user` (`user_pk`),
  CONSTRAINT `FKt58e9mdgxpl7j90ketlaosmx4` FOREIGN KEY (`reviewer_id`) REFERENCES `user` (`user_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (1,NULL,1,8,13),(2,NULL,5,15,8),(3,NULL,5,8,15),(4,NULL,2,17,3),(5,NULL,5,17,6),(6,NULL,1,6,17),(7,NULL,5,5,1),(8,NULL,5,1,5),(9,NULL,4,21,20),(10,NULL,5,18,20);
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room` (
  `room_id` int NOT NULL AUTO_INCREMENT,
  `buyer_out` int DEFAULT '0',
  `in_user` int DEFAULT '0',
  `is_read` int DEFAULT '0',
  `last_message` varchar(255) DEFAULT NULL,
  `seller_out` int DEFAULT '0',
  `buyer_id` int DEFAULT NULL,
  `seller_id` int DEFAULT NULL,
  PRIMARY KEY (`room_id`),
  KEY `FKhls1klqc0vfj386sulw9m2yx0` (`buyer_id`),
  KEY `FKl809s6kx8lj6b8xrpfea18od8` (`seller_id`),
  CONSTRAINT `FKhls1klqc0vfj386sulw9m2yx0` FOREIGN KEY (`buyer_id`) REFERENCES `user` (`user_pk`),
  CONSTRAINT `FKl809s6kx8lj6b8xrpfea18od8` FOREIGN KEY (`seller_id`) REFERENCES `user` (`user_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (2,1,2,0,'그건 쫌,,',0,8,13),(7,0,9,0,'네',0,17,6),(8,0,4,0,'ㅗㅓㅗㅓㅓ',0,3,17),(9,0,2,0,'님님',0,3,13),(10,0,3,0,'헉 ㅜㅜ',0,13,7),(12,0,3,0,'넵~ 내일 뵙겠습니다~',0,15,7),(13,0,2,0,'사인 축구공이엇습니다 ㅜ',0,18,8),(14,0,2,0,'알겠습니다',0,1,5),(15,0,1,0,'',0,8,5),(16,0,1,0,'ㅋㅋㅋㅋㅋㅋㅋ',0,10,6),(17,0,1,0,'갤럭시 플립 파시나요?',0,10,1),(18,0,0,0,'안녕하세요! 플립3 상품 구매 원합니다!',0,5,1),(19,0,3,0,'아냐.. 아는걸로해...',0,18,7),(20,0,2,0,'ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ',0,18,19),(21,0,1,0,'오 메시지 남아있네',0,20,21),(22,0,1,0,'아',0,20,18);
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_read`
--

DROP TABLE IF EXISTS `room_read`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room_read` (
  `read_id` int NOT NULL AUTO_INCREMENT,
  `buyer_chat` int DEFAULT '0',
  `seller_chat` int DEFAULT '0',
  `total_chat` int DEFAULT '0',
  `roomid` int DEFAULT NULL,
  PRIMARY KEY (`read_id`),
  KEY `FK577ti4fld5um3fsn91r9ncc8v` (`roomid`),
  CONSTRAINT `FK577ti4fld5um3fsn91r9ncc8v` FOREIGN KEY (`roomid`) REFERENCES `room` (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_read`
--

LOCK TABLES `room_read` WRITE;
/*!40000 ALTER TABLE `room_read` DISABLE KEYS */;
INSERT INTO `room_read` VALUES (2,20,20,20,2),(7,15,24,24,7),(8,23,23,23,8),(9,27,27,27,9),(10,28,30,30,10),(12,42,42,42,12),(13,53,53,53,13),(14,46,46,46,14),(15,0,0,0,15),(16,48,0,48,16),(17,49,49,49,17),(18,50,0,50,18),(19,60,60,60,19),(20,59,57,59,20),(21,63,63,63,21),(22,91,91,91,22);
/*!40000 ALTER TABLE `room_read` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag` (
  `tag_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` VALUES (1,'아이폰'),(2,'급처'),(3,'핸드폰'),(4,'애플'),(5,'태블릿'),(6,'아이패드'),(7,'가전'),(8,'공구'),(9,'공구함'),(10,'음료수'),(11,'탄산'),(12,'모니터'),(13,'디지털'),(14,'전자'),(15,'스피커'),(16,'울산'),(17,'광주'),(18,'인형'),(19,'생활가전'),(20,'안마'),(21,'의자'),(22,'시디즈'),(23,'SIDIZ'),(24,'여수'),(25,'플스'),(26,'플스3'),(27,'게임'),(28,'직거래'),(29,'썬크림'),(30,'철물'),(31,'동구'),(32,'폐업'),(33,'상무'),(34,'뉴발란스'),(35,'530'),(36,'230'),(37,'스마트워치'),(38,'워치'),(39,'시계'),(40,'로션'),(41,'데일리'),(42,'더심플'),(43,'에어팟'),(44,'이어폰'),(45,'무선'),(46,'ㅇㅇ'),(47,'냉장고'),(48,'미니냉장고'),(49,'123'),(50,'무드등'),(51,'말랑이'),(52,'해리포터'),(53,'소설'),(54,'시리즈'),(55,'축구공'),(56,'손흥민'),(57,'싸인'),(58,'친필'),(59,'침대'),(60,'프레임'),(61,'매트리스'),(62,'슈퍼싱글'),(63,'디지털피아노'),(64,'삼성'),(65,'세련된'),(66,'인테리어'),(67,'미개봉'),(68,'여행'),(69,'갤럭시'),(70,'노트'),(71,'갤럭시노트'),(72,'휴대폰'),(73,'취미'),(74,'골프'),(75,'아이언'),(76,'아이폰13'),(77,'핸드폰케이스'),(78,'나이키'),(79,'NIKE'),(80,'조던'),(81,'신발'),(82,'패션'),(83,'메이플'),(84,'루나'),(85,'호영'),(86,'떵유'),(87,'캐릭터'),(88,'지갑'),(89,'카드지갑'),(90,'마르지엘라'),(91,'나주'),(92,'에어포스'),(93,'범고래'),(94,'덩크'),(95,'식탁'),(96,'테이블'),(97,'책상'),(98,'4인용'),(99,'납'),(100,'회로'),(101,'전자공학과'),(102,'납땜'),(103,'헬스'),(104,'홈짐'),(105,'운동'),(106,'제습기'),(107,'블루투스'),(108,'마이크'),(109,'스타벅스'),(110,'기프티콘'),(111,'노트북'),(112,'랩탑'),(113,'데스크탑'),(114,'컴퓨터'),(115,'본체'),(116,'3060'),(117,'게임용'),(118,'전기면도기'),(119,'브라운'),(120,'면도기'),(121,'자격증'),(122,'외환전문역'),(123,'외전역'),(124,'cpu'),(125,'인텔'),(126,'7500'),(127,'마우스'),(128,'티셔츠'),(129,'상의'),(130,'여름'),(131,'강아지'),(132,'너무'),(133,'귀여워'),(134,'싸피'),(135,'ssafy'),(136,'향수'),(137,'농구'),(138,'농구공'),(139,'야구'),(140,'글러브'),(141,'운동기구'),(142,'이케아'),(143,'드라이기'),(144,'갤럭시워치'),(145,'청소기'),(146,'다리미'),(147,'컨버스'),(148,'양자역학'),(149,'카카오프렌즈'),(150,'러피치'),(151,'어피치'),(152,'춘식이'),(153,'선풍기'),(154,'공기청정기'),(155,'미세먼지'),(156,'먼지'),(157,'기사'),(158,'정보처리기사'),(159,'정처기'),(160,'TV'),(161,'스마트티비'),(162,'에어프라이어'),(163,'전자레인지'),(164,'아이스크림'),(165,'버즈'),(166,'빔프로젝터'),(167,'스크린'),(168,'영화'),(169,'축구화'),(170,'수납장'),(171,'티비받침대'),(172,'양궁'),(173,'갤럭시탭'),(174,'매니큐어'),(175,'펜션'),(176,'숙소'),(177,'스키장'),(178,'카메라'),(179,'디지털카메라'),(180,'건조기'),(181,'장마'),(182,'빨래'),(183,'적외선센서'),(184,'센서'),(185,'아두이노'),(186,'누텔라'),(187,'스마트폰'),(188,'플립'),(189,'원피스'),(190,'퍼즐'),(191,'스티커'),(192,'포켓몬'),(193,'맥'),(194,'섀도우'),(195,'메이크업');
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag_product`
--

DROP TABLE IF EXISTS `tag_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag_product` (
  `tag_product_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `tag_id` int DEFAULT NULL,
  PRIMARY KEY (`tag_product_id`),
  KEY `FK1s1ggam66t2pyma2id6r8yvpp` (`product_id`),
  KEY `FKj6en359cskvk76ak9q6q0vu37` (`tag_id`),
  CONSTRAINT `FK1s1ggam66t2pyma2id6r8yvpp` FOREIGN KEY (`product_id`) REFERENCES `product` (`no`),
  CONSTRAINT `FKj6en359cskvk76ak9q6q0vu37` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=298 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag_product`
--

LOCK TABLES `tag_product` WRITE;
/*!40000 ALTER TABLE `tag_product` DISABLE KEYS */;
INSERT INTO `tag_product` VALUES (1,'아이폰',1,1),(2,'급처',1,2),(3,'급처',2,2),(4,'아이폰',2,1),(5,'핸드폰',2,3),(6,'애플',3,4),(7,'태블릿',3,5),(8,'아이패드',3,6),(9,'가전',4,7),(10,'공구',4,8),(11,'공구함',4,9),(12,'음료수',5,10),(13,'탄산',5,11),(14,'모니터',6,12),(15,'디지털',6,13),(16,'전자',6,14),(17,'스피커',7,15),(18,'전자',7,14),(19,'울산',7,16),(22,'생활가전',9,19),(23,'광주',9,17),(24,'안마',9,20),(25,'의자',10,21),(26,'시디즈',10,22),(27,'SIDIZ',10,23),(28,'여수',11,24),(29,'플스',11,25),(30,'플스3',11,26),(31,'게임',11,27),(32,'광주',12,17),(33,'직거래',12,28),(34,'썬크림',12,29),(35,'철물',13,30),(36,'광주',13,17),(37,'동구',13,31),(38,'폐업',13,32),(39,'상무',14,33),(40,'광주',14,17),(41,'뉴발란스',14,34),(42,'530',14,35),(43,'230',14,36),(44,'스마트워치',15,37),(45,'애플',15,4),(46,'워치',15,38),(47,'시계',15,39),(48,'로션',16,40),(49,'데일리',16,41),(50,'광주',16,17),(51,'더심플',16,42),(52,'에어팟',17,43),(53,'애플',17,4),(54,'이어폰',17,44),(55,'무선',17,45),(57,'냉장고',19,47),(58,'미니냉장고',19,48),(60,'광주',23,17),(61,'직거래',23,28),(62,'무드등',23,50),(63,'말랑이',23,51),(64,'해리포터',24,52),(65,'소설',24,53),(66,'시리즈',24,54),(67,'축구공',25,55),(68,'손흥민',25,56),(69,'싸인',25,57),(70,'친필',25,58),(71,'침대',26,59),(72,'프레임',26,60),(73,'매트리스',26,61),(74,'슈퍼싱글',26,62),(75,'디지털피아노',27,63),(76,'삼성',27,64),(77,'세련된',27,65),(78,'인테리어',27,66),(79,'모니터',28,12),(80,'삼성',28,64),(81,'미개봉',28,67),(82,'직거래',28,28),(83,'여행',29,68),(84,'의자',29,21),(85,'갤럭시',30,69),(86,'삼성',30,64),(87,'노트',30,70),(88,'갤럭시노트',30,71),(89,'휴대폰',30,72),(90,'취미',31,73),(91,'골프',31,74),(92,'아이언',31,75),(93,'아이폰13',32,76),(94,'핸드폰케이스',32,77),(95,'나이키',33,78),(96,'NIKE',33,79),(97,'조던',33,80),(98,'신발',33,81),(99,'조던',34,80),(100,'신발',34,81),(101,'패션',34,82),(107,'지갑',36,88),(108,'카드지갑',36,89),(109,'마르지엘라',36,90),(113,'나이키',38,78),(114,'NIKE',38,79),(115,'에어포스',38,92),(116,'신발',38,81),(117,'메이플',39,83),(118,'루나',39,84),(119,'호영',39,85),(120,'떵유',39,86),(121,'나이키',40,78),(122,'범고래',40,93),(123,'덩크',40,94),(124,'신발',40,81),(126,'식탁',42,95),(127,'테이블',42,96),(128,'책상',42,97),(129,'4인용',42,98),(130,'납',43,99),(131,'회로',43,100),(132,'전자공학과',43,101),(133,'납땜',43,102),(134,'헬스',44,103),(135,'홈짐',44,104),(136,'운동',44,105),(137,'제습기',45,106),(138,'블루투스',46,107),(139,'마이크',46,108),(140,'스타벅스',47,109),(141,'기프티콘',47,110),(142,'노트북',48,111),(143,'랩탑',48,112),(144,'데스크탑',48,113),(145,'컴퓨터',49,114),(146,'본체',49,115),(147,'3060',49,116),(148,'게임용',49,117),(149,'전기면도기',50,118),(150,'브라운',50,119),(151,'면도기',50,120),(152,'자격증',51,121),(153,'외환전문역',51,122),(154,'외전역',51,123),(155,'cpu',52,124),(156,'인텔',52,125),(157,'7500',52,126),(158,'마우스',53,127),(159,'블루투스',53,107),(160,'무선',53,45),(161,'조던',54,80),(162,'나이키',54,78),(163,'신발',54,81),(167,'티셔츠',55,128),(168,'상의',55,129),(169,'여름',55,130),(170,'강아지',56,131),(171,'너무',56,132),(172,'귀여워',56,133),(175,'향수',58,136),(180,'농구',60,137),(181,'농구공',60,138),(182,'야구',61,139),(183,'글러브',61,140),(184,'직거래',62,28),(185,'광주',63,17),(186,'운동기구',63,141),(187,'갤럭시',64,69),(188,'스마트워치',64,37),(189,'워치',64,38),(190,'삼성',64,64),(194,'책상',65,97),(195,'이케아',65,142),(196,'생활가전',66,19),(197,'드라이기',66,143),(200,'인형',68,18),(204,'갤럭시워치',71,144),(205,'워치',71,38),(206,'갤럭시',71,69),(207,'청소기',72,145),(208,'다리미',73,146),(210,'컨버스',74,147),(211,'양자역학',75,148),(212,'카카오프렌즈',76,149),(213,'러피치',76,150),(214,'어피치',76,151),(215,'카카오프렌즈',77,149),(216,'춘식이',77,152),(217,'광주',8,17),(218,'인형',8,18),(219,'선풍기',79,153),(220,'삼성',80,64),(221,'싸피',80,134),(222,'ssafy',80,135),(223,'공기청정기',81,154),(224,'미세먼지',81,155),(225,'먼지',81,156),(226,'기사',82,157),(227,'정보처리기사',82,158),(228,'정처기',82,159),(231,'삼성',83,64),(232,'TV',83,160),(233,'스마트티비',83,161),(234,'에어프라이어',84,162),(235,'전자레인지',84,163),(236,'냉장고',85,47),(237,'아이스크림',85,164),(238,'삼성',86,64),(239,'갤럭시',86,69),(240,'버즈',86,165),(241,'이어폰',86,44),(242,'빔프로젝터',87,166),(243,'스크린',87,167),(244,'영화',87,168),(245,'축구화',88,169),(246,'이케아',89,142),(247,'수납장',89,170),(248,'티비받침대',89,171),(249,'양궁',90,172),(250,'삼성',91,64),(251,'갤럭시',91,69),(252,'갤럭시탭',91,173),(253,'태블릿',91,5),(255,'매니큐어',92,174),(256,'펜션',93,175),(257,'숙소',93,176),(258,'스키장',93,177),(259,'삼성',94,64),(260,'갤럭시',94,69),(264,'싸피',57,134),(265,'ssafy',57,135),(266,'삼성',57,64),(267,'삼성',95,64),(268,'카메라',95,178),(269,'디지털카메라',95,179),(270,'삼성',96,64),(271,'건조기',96,180),(272,'장마',96,181),(273,'빨래',96,182),(274,'적외선센서',97,183),(275,'센서',97,184),(276,'아두이노',97,185),(277,'회로',97,100),(278,'누텔라',98,186),(279,'블루투스',99,107),(280,'센서',99,184),(281,'아두이노',99,185),(282,'삼성',100,64),(283,'스마트폰',100,187),(284,'플립',100,188),(285,'삼성',101,64),(286,'플립',101,188),(287,'스마트폰',101,187),(288,'원피스',102,189),(289,'퍼즐',102,190),(290,'카카오프렌즈',103,149),(291,'스티커',103,191),(292,'포켓몬',104,192),(293,'인형',104,18),(294,'인형',105,18),(295,'맥',115,193),(296,'섀도우',115,194),(297,'메이크업',115,195);
/*!40000 ALTER TABLE `tag_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_pk` int NOT NULL AUTO_INCREMENT,
  `create_date` datetime(6) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `nickname` varchar(10) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `profile_url` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `score` double NOT NULL,
  `userid` varchar(255) DEFAULT NULL,
  `username` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`user_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'2022-08-17 17:08:56.465000','dudgns1239@naver.com','슬슬이','$2a$10$i01tgjOi7ixuWH0qlMh1X.N3l9lzzR7iuu4ctud6bmFkvKGro4HRe','/images/profile/basic.png','ROLE_ADMIN',57,'dudgnscjstk','조영훈'),(2,'2022-08-18 02:52:19.567000','tmpemail@naver.com','관리자닉네임','$2a$10$VkKjlCpsd0j.TNYWClMVQezeRTXgFDhawonYqHMFIqWMDucKj3bTy','/images/profile/basic.png','ROLE_ADMIN',55,'admin','관리자이름'),(3,'2022-08-18 02:52:39.708000','tmpemail@naver.com','사용자닉네임','$2a$10$w.qDHUkKivueQZ0hqk9X6.fonmK2m/Ajd1qHcywdTeZNO03Q/LEi6','/images/profile/basic.png','ROLE_USER',55,'user','사용자이름'),(4,'2022-08-18 02:54:57.958000','tmpemail@naver.com','조영훈닉네임','$2a$10$4d2MfBCaauoTsCXTiO75Qe1rceah3N2vL6VfJZDQ0fgZhbvguB.K2','/images/profile/basic.png','ROLE_USER',55,'조영훈','조영훈이름'),(5,'2022-08-18 02:57:50.226000','tmpemail@naver.com','김싸피','$2a$10$sTTOgVhh5ZwG4sJPTFlMZOj9AKvo5guwmpelhixKxpR313kgwHw.q','/images/profile/GDChg3N4tRL4HdXjtelGm3J6AJ755WEh.jpg','ROLE_USER',57,'김싸피','김싸피'),(6,'2022-08-18 00:17:10.689000','dlalswo9801@naver.com','모아이','$2a$10$Q3v8qhqw21c66qdK9xRZ0udx49NZaGpMw9f6Qooka42nCIExa.iQG','/images/profile/iexct2hEuDaQPgbSwmy6ZaW4BeETmVUE.jpg','ROLE_USER',53,'dlalswo9801','이민재'),(7,'2022-08-18 00:21:34.711000','haengsong@naver.com','햄솜','$2a$10$Y28cdpNH5Mxl8v3L2gGLeuXzK5CY8XQ4SgBcSjYezPDgzIsXoNoOy','/images/profile/Rwt9QtifBDgpUiVQIY7cSyLEtkXOkHso.jpeg','ROLE_USER',55,'haengsong','오행송'),(8,'2022-08-18 00:36:28.723000','lgh3806@naver.com','이건후','$2a$10$C7SceczqJlKdCmsx4wc5GOnEqBpJR9/j.dFXYUCT2B5xLCG6d7Nvm','/images/profile/yG4h01MYFSlTMFgtRgMHk4yiYqw3z6Sl.jpg','ROLE_USER',55,'hoo','hoo'),(10,'2022-08-18 00:55:19.549000','myuju419@naver.com','yuzu','$2a$10$DNarocqMp2N1xOobpfaGeOti7t8qMG4MC7DrqwHKNcPqEY3RwylUy','/images/profile/3i2JqA2hk6kHwRMOzokTJ9NZgvVcaO2Z.jpeg','ROLE_USER',55,'yuzu1','문유주'),(12,'2022-08-18 10:13:28.553000','tmpemail@naver.com','너납치된거야','$2a$10$NfoVZVbztQdILddPsoCPm.61WqtYS4BJNs1nUbHm5jUs1GmyVhkNK','/images/profile/basic.png','ROLE_USER',55,'너납치된거야','강해상'),(13,'2022-08-18 01:26:46.474000','ehddb2252@gmail.com','떵유','$2a$10$UGHyEQybU.m14.zdH8F4Rur/tiG0QninPIs21GyitfUpLw528cLma','/images/profile/RGEi1qoCPiInFMppcphHMIf7IIk9G3vt.png','ROLE_USER',55,'ehddb2252','짭피'),(15,'2022-08-18 01:41:57.611000','lgh2308@gmail.com','solsol','$2a$10$KFGeQruJESIG5O6eL4HN/.EBb6Jn3IliVB3iWH1zooQ5AaZXWUkze','/images/profile/8T9waABAAQy8KSJZW2lOah6gNU7RbDFd.jpg','ROLE_USER',57,'soldsolve','김솔솔'),(16,'2022-08-18 01:48:06.189000','cheuora@gmail.com','cheuora','$2a$10$gMdjkZy7aIdvn45h/pWgIu5ldcY08c4lpxa2POdDW5cqOOxHyUmvG','/images/profile/basic.png','ROLE_USER',55,'cheuora@gmail.com','게부라'),(17,'2022-08-18 02:11:16.043000','uiui96@naver.com','이만득','$2a$10$rAUBxKA/p5JD/CCLSzwAyeL0DXNgjl3AfqB0Y7bPLCTEgxLxK6NUS','/images/profile/basic.png','ROLE_USER',55.5,'alswo96','이민재'),(18,'2022-08-18 10:37:01.025000','myuju0419@gmail.com','yuzu2','$2a$10$oJnx8k9xQtpjpDA9MgUHgekVIAisH5elv5QbhPhM/2ucpDJee12P.','/images/profile/basic.png','ROLE_USER',57,'yuzu2','문유주'),(19,'2022-08-18 14:25:35.583000','sehhhh16@gmail.com','칠삼','$2a$10$O86smJgzka5p5n1PB6n2XOYMYvZqHITx6cMt9bxDJ/y9j7xlhWbG6','/images/profile/basic.png','ROLE_USER',55,'chilsam','최칠삼'),(20,'2022-08-18 14:31:24.087000','suaveh3681@gmail.com','ssafy','$2a$10$yEzgd4tkU6aPeco0S5dyleFBJY7D2D1PFtHy/Q/NQWBTD3nu0/FNi','/images/profile/basic.png','ROLE_USER',55,'ssafy','ssafy'),(21,'2022-08-18 14:55:52.018000','yoonjuhye6@gmail.com','킁킁','$2a$10$.UG52xnJXBH33dN/SAt0PeMQDTzw7rDqjnZt0v2vUpUBgFrimMAsS','/images/profile/basic.png','ROLE_USER',56,'yoon123','킁킁');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wish`
--

DROP TABLE IF EXISTS `wish`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wish` (
  `wish_id` int NOT NULL AUTO_INCREMENT,
  `no` int DEFAULT NULL,
  `user_pk` int DEFAULT NULL,
  PRIMARY KEY (`wish_id`),
  KEY `FKtg2b1i7vsfts3lr4256dy7br0` (`no`),
  KEY `FKpwfltcoxnl9vi59h6ljl9k5dn` (`user_pk`),
  CONSTRAINT `FKpwfltcoxnl9vi59h6ljl9k5dn` FOREIGN KEY (`user_pk`) REFERENCES `user` (`user_pk`),
  CONSTRAINT `FKtg2b1i7vsfts3lr4256dy7br0` FOREIGN KEY (`no`) REFERENCES `product` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wish`
--

LOCK TABLES `wish` WRITE;
/*!40000 ALTER TABLE `wish` DISABLE KEYS */;
INSERT INTO `wish` VALUES (2,28,13),(3,17,10),(4,11,10),(8,23,15),(9,61,8),(10,58,8),(11,16,17),(12,30,17),(13,66,17),(14,39,3),(15,39,10),(16,61,15),(17,19,18),(18,25,18),(19,1,10),(20,39,7),(21,100,10),(22,100,5),(23,101,10),(24,100,7),(25,104,1),(26,103,1),(27,100,18),(28,109,18),(29,112,18),(30,8,18),(31,113,20);
/*!40000 ALTER TABLE `wish` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 10:49:29
