-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: i7c110.p.ssafy.io    Database: soldsolve
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice` (
  `notice_id` int NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `written_times` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`notice_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice`
--

LOCK TABLES `notice` WRITE;
/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
INSERT INTO `notice` VALUES (1,'안녕하세요.\nSold Solve 제작팀입니다.\n2022년 8월 18일자로 Sold Solve가 공식적으로 오픈하게 되었습니다. 많은 축하와 관심 부탁드립니다.\n부족한 점이 많을 수 있습니다. 불편한 점은 언제든지 건의해주시면 개선하도록 노력하겠습니다.\n\n감사합니다.\n다들 공통 프로젝트하느라 고생하셨습니다.','[공지] Sold Solve 공식 오픈','2022-08-18 02:45:26.237000'),(3,'안녕하세요 쏠쏠개발팀입니다.\n\n8월19일 자정에 발표준비를 위한 최종 빌드 작업이 있으므로\n10분간 서비스 사용이중단됩니다.\n\n발표 화이팅입니다.','[점검] 8월19일 00시00분 ~ 00시10분 웹페이지 점검','2022-08-18 14:11:20.044000'),(5,'안녕하세요.\n쏠드쏠브 개발팀 입니다.\n\n쏠쏠의 새로운 기능  \"실시간 인기검색어\" 가 추가되었습니다.\n모든 유저들은 메인화면에 다른 유저들이 어떤 것을 많이 찾는지 쉽게 확인 할 수 있도록 실시간 인기검색어 기능을 구현하게 되었습니다.\n\n많은 이용 바랍니다.','[업데이트]  인기검색어 업데이트','2022-08-18 14:14:23.345000');
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 10:50:26
