-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: i7c110.p.ssafy.io    Database: soldsolve
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `request`
--

DROP TABLE IF EXISTS `request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request` (
  `request_id` int NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) DEFAULT NULL,
  `userid` varchar(255) DEFAULT NULL,
  `no` int DEFAULT NULL,
  `user_pk` int DEFAULT NULL,
  PRIMARY KEY (`request_id`),
  KEY `FK21pmulsthu3ihkocip0p8leui` (`no`),
  KEY `FK8rbmtvb32i1qxlr3tbwnpfk9d` (`user_pk`),
  CONSTRAINT `FK21pmulsthu3ihkocip0p8leui` FOREIGN KEY (`no`) REFERENCES `product` (`no`),
  CONSTRAINT `FK8rbmtvb32i1qxlr3tbwnpfk9d` FOREIGN KEY (`user_pk`) REFERENCES `user` (`user_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `request`
--

LOCK TABLES `request` WRITE;
/*!40000 ALTER TABLE `request` DISABLE KEYS */;
INSERT INTO `request` VALUES (2,'떵유','ehddb2252',28,13),(3,'yuzu','yuzu1',17,10),(4,'yuzu','yuzu1',11,10),(7,'솔드솔브','soldsolve',23,15),(8,'이만득','alswo96',16,17),(9,'사용자닉네임','user',63,3),(10,'이만득','alswo96',5,17),(11,'이만득','alswo96',66,17),(12,'사용자닉네임','user',39,3),(13,'yuzu','yuzu1',57,10),(14,'solsol','soldsolve',61,15),(15,'yuzu','yuzu1',58,10),(16,'yuzu','yuzu1',100,10),(17,'김싸피','김싸피',100,5),(18,'yuzu','yuzu1',101,10),(19,'햄솜','haengsong',100,7),(21,'yuzu2','yuzu2',100,18),(22,'너납치된거야','너납치된거야',100,12),(23,'yuzu2','yuzu2',46,18),(24,'yuzu2','yuzu2',112,18),(25,'햄솜','haengsong',112,7),(27,'ssafy','ssafy',113,20),(28,'ssafy','ssafy',105,20),(29,'모아이','dlalswo9801',101,6),(30,'모아이','dlalswo9801',100,6);
/*!40000 ALTER TABLE `request` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 10:50:21
