-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: i7c110.p.ssafy.io    Database: soldsolve
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_pk` int NOT NULL AUTO_INCREMENT,
  `create_date` datetime(6) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `nickname` varchar(10) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `profile_url` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `score` double NOT NULL,
  `userid` varchar(255) DEFAULT NULL,
  `username` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`user_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'2022-08-17 17:08:56.465000','dudgns1239@naver.com','슬슬이','$2a$10$i01tgjOi7ixuWH0qlMh1X.N3l9lzzR7iuu4ctud6bmFkvKGro4HRe','/images/profile/basic.png','ROLE_ADMIN',57,'dudgnscjstk','조영훈'),(2,'2022-08-18 02:52:19.567000','tmpemail@naver.com','관리자닉네임','$2a$10$VkKjlCpsd0j.TNYWClMVQezeRTXgFDhawonYqHMFIqWMDucKj3bTy','/images/profile/basic.png','ROLE_ADMIN',55,'admin','관리자이름'),(3,'2022-08-18 02:52:39.708000','tmpemail@naver.com','사용자닉네임','$2a$10$w.qDHUkKivueQZ0hqk9X6.fonmK2m/Ajd1qHcywdTeZNO03Q/LEi6','/images/profile/basic.png','ROLE_USER',55,'user','사용자이름'),(4,'2022-08-18 02:54:57.958000','tmpemail@naver.com','조영훈닉네임','$2a$10$4d2MfBCaauoTsCXTiO75Qe1rceah3N2vL6VfJZDQ0fgZhbvguB.K2','/images/profile/basic.png','ROLE_USER',55,'조영훈','조영훈이름'),(5,'2022-08-18 02:57:50.226000','tmpemail@naver.com','김싸피','$2a$10$sTTOgVhh5ZwG4sJPTFlMZOj9AKvo5guwmpelhixKxpR313kgwHw.q','/images/profile/GDChg3N4tRL4HdXjtelGm3J6AJ755WEh.jpg','ROLE_USER',57,'김싸피','김싸피'),(6,'2022-08-18 00:17:10.689000','dlalswo9801@naver.com','모아이','$2a$10$Q3v8qhqw21c66qdK9xRZ0udx49NZaGpMw9f6Qooka42nCIExa.iQG','/images/profile/iexct2hEuDaQPgbSwmy6ZaW4BeETmVUE.jpg','ROLE_USER',53,'dlalswo9801','이민재'),(7,'2022-08-18 00:21:34.711000','haengsong@naver.com','햄솜','$2a$10$Y28cdpNH5Mxl8v3L2gGLeuXzK5CY8XQ4SgBcSjYezPDgzIsXoNoOy','/images/profile/Rwt9QtifBDgpUiVQIY7cSyLEtkXOkHso.jpeg','ROLE_USER',55,'haengsong','오행송'),(8,'2022-08-18 00:36:28.723000','lgh3806@naver.com','이건후','$2a$10$C7SceczqJlKdCmsx4wc5GOnEqBpJR9/j.dFXYUCT2B5xLCG6d7Nvm','/images/profile/yG4h01MYFSlTMFgtRgMHk4yiYqw3z6Sl.jpg','ROLE_USER',55,'hoo','hoo'),(10,'2022-08-18 00:55:19.549000','myuju419@naver.com','yuzu','$2a$10$DNarocqMp2N1xOobpfaGeOti7t8qMG4MC7DrqwHKNcPqEY3RwylUy','/images/profile/3i2JqA2hk6kHwRMOzokTJ9NZgvVcaO2Z.jpeg','ROLE_USER',55,'yuzu1','문유주'),(12,'2022-08-18 10:13:28.553000','tmpemail@naver.com','너납치된거야','$2a$10$NfoVZVbztQdILddPsoCPm.61WqtYS4BJNs1nUbHm5jUs1GmyVhkNK','/images/profile/basic.png','ROLE_USER',55,'너납치된거야','강해상'),(13,'2022-08-18 01:26:46.474000','ehddb2252@gmail.com','떵유','$2a$10$UGHyEQybU.m14.zdH8F4Rur/tiG0QninPIs21GyitfUpLw528cLma','/images/profile/RGEi1qoCPiInFMppcphHMIf7IIk9G3vt.png','ROLE_USER',55,'ehddb2252','짭피'),(15,'2022-08-18 01:41:57.611000','lgh2308@gmail.com','solsol','$2a$10$KFGeQruJESIG5O6eL4HN/.EBb6Jn3IliVB3iWH1zooQ5AaZXWUkze','/images/profile/8T9waABAAQy8KSJZW2lOah6gNU7RbDFd.jpg','ROLE_USER',57,'soldsolve','김솔솔'),(16,'2022-08-18 01:48:06.189000','cheuora@gmail.com','cheuora','$2a$10$gMdjkZy7aIdvn45h/pWgIu5ldcY08c4lpxa2POdDW5cqOOxHyUmvG','/images/profile/basic.png','ROLE_USER',55,'cheuora@gmail.com','게부라'),(17,'2022-08-18 02:11:16.043000','uiui96@naver.com','이만득','$2a$10$rAUBxKA/p5JD/CCLSzwAyeL0DXNgjl3AfqB0Y7bPLCTEgxLxK6NUS','/images/profile/basic.png','ROLE_USER',55.5,'alswo96','이민재'),(18,'2022-08-18 10:37:01.025000','myuju0419@gmail.com','yuzu2','$2a$10$oJnx8k9xQtpjpDA9MgUHgekVIAisH5elv5QbhPhM/2ucpDJee12P.','/images/profile/basic.png','ROLE_USER',57,'yuzu2','문유주'),(19,'2022-08-18 14:25:35.583000','sehhhh16@gmail.com','칠삼','$2a$10$O86smJgzka5p5n1PB6n2XOYMYvZqHITx6cMt9bxDJ/y9j7xlhWbG6','/images/profile/basic.png','ROLE_USER',55,'chilsam','최칠삼'),(20,'2022-08-18 14:31:24.087000','suaveh3681@gmail.com','ssafy','$2a$10$yEzgd4tkU6aPeco0S5dyleFBJY7D2D1PFtHy/Q/NQWBTD3nu0/FNi','/images/profile/basic.png','ROLE_USER',55,'ssafy','ssafy'),(21,'2022-08-18 14:55:52.018000','yoonjuhye6@gmail.com','킁킁','$2a$10$.UG52xnJXBH33dN/SAt0PeMQDTzw7rDqjnZt0v2vUpUBgFrimMAsS','/images/profile/basic.png','ROLE_USER',56,'yoon123','킁킁');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 10:50:23
